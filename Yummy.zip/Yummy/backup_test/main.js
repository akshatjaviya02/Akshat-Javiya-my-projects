function hello() {
    console.log("Hello, World!");
}
function html() {
    document.getElementById("hello").innerHTML = "Hello World";
}
hello();

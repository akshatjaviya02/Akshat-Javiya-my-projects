//---------------------------------------------------------------------------------
//                  Group Names : Shayan Darian, Gilbert Galvan, Akshat Javiya
//                  Assignment  : Group Project
//                  Due Date    : 12/06/2022
// Purpose : This program is using Parsing table to decide wheather the program
// is rejected to accepted.
//---------------------------------------------------------------------------------
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <stack>
#include <string>
#include <vector>
#define ROW_SIZE 67
#define COLUMN_SIZE 3

int main(int args, char *argv[])
{
  std::string reserved_words[11] = {"program", "var", "beign", "end.",
                                    "integer", "print", ";", ",",
                                    ".", "(", "("};
  std::string letter[5] = {"a", "b", "c", "d", "f"};
  std::string digits[10] = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"};
  std::stack<std::string> grammar;
  std::stack<std::string> expression;
  std::map<std::string, int> variables;
  std::vector<std::string> equations;
  std::string table[ROW_SIZE][COLUMN_SIZE] = {
      {"A", "i", "i=E;"},
      {"A", "n", "BLANK"},
      {"A", "+", "BLANK"},
      {"A", "-", "BLANK"},
      {"A", "*", "BLANK"},
      {"A", "/", "BLANK"},
      {"A", "(", "BLANK"},
      {"A", ")", "BLANK"},
      {"A", "$", "BLANK"},
      {"A", ";", "BLANK"},
      {"A", "=", "BLANK"},
      {"E", "i", "TQ"},
      {"E", "n", "TQ"},
      {"E", "+", "BLANK"},
      {"E", "-", "BLANK"},
      {"E", "*", "BLANK"},
      {"E", "/", "BLANK"},
      {"E", "(", "TQ"},
      {"E", ")", "BLANK"},
      {"E", "$", "BLANK"},
      {"E", ";", "BLANK"},
      {"E", "=", "BLANK"},
      {"Q", "i", "BLANK"},
      {"Q", "n", "BLANK"},
      {"Q", "+", "+TQ"},
      {"Q", "-", "-TQ"},
      {"Q", "*", "BLANK"},
      {"Q", "/", "BLANK"},
      {"Q", "(", "BLANK"},
      {"Q", ")", "λ"},
      {"Q", "$", "BLANK"},
      {"Q", ";", "λ"},
      {"Q", "=", "BLANK"},
      {"T", "i", "FR"},
      {"T", "n", "FR"},
      {"T", "+", "BLANK"},
      {"T", "-", "BLANK"},
      {"T", "*", "BLANK"},
      {"T", "/", "BLANK"},
      {"T", "(", "FR"},
      {"T", ")", "BLANK"},
      {"T", "$", "BLANK"},
      {"T", ";", "BLANK"},
      {"T", "=", "BLANK"},
      {"R", "i", "BLANK"},
      {"R", "n", "BLANK"},
      {"R", "+", "λ"},
      {"R", "-", "λ"},
      {"R", "*", "*FR"},
      {"R", "/", "/FR"},
      {"R", "(", "BLANK"},
      {"R", ")", "λ"},
      {"R", "$", "BLANK"},
      {"R", ";", "λ"},
      {"R", "=", "BLANK"},
      {"F", "i", "i"},
      {"F", "n", "n"},
      {"F", "+", "BLANK"},
      {"F", "-", "BLANK"},
      {"F", "*", "BLANK"},
      {"F", "/", "BLANK"},
      {"F", "(", "(E)"},
      {"F", ")", "BLANK"},
      {"F", "$", "BLANK"},
      {"F", ";", "BLANK"},
      {"F", "=", "BLANK"},
  };
  std::string line, line2, equation;
  std::ifstream file1;
  std::ofstream file_2;
  file_2.open("finalp2.txt");
  file1.open(argv[1]);
  if (file1.is_open())
  {
    bool comment = false;
    while (std::getline(file1, line))
    {
      line2 = "";
      for (size_t i = 0; i < line.length(); i++)
      {
        if (comment == true && line[i] == '*' && line[i + 1] == '*')
        {
          comment = false;
          i++;
        }
        else if (comment)
        {
          continue;
        }
        else if (line[i] == '*' && line[i + 1] == '*')
        {
          comment = true;
          i++;
        }
        else if ((isspace(line[i]) && isspace(line[i + 1])))
        {
          continue;
        }
        else
        {
          line2 += line[i];
        }
      }
      if (line2.length() == 0 || isspace(line2[0]))
      {
        continue;
      }
      else
      {
        if (isspace(*(line2.end() - 1)))
        {
          line2.erase(line2.end() - 1);
        }
        file_2 << line2 << '\n';
        equations.push_back(line2);
        line2 += " ";
      }
    }
  }
  file1.close();
  file_2.close();
  std::string output;
  line2 = (*(equations.end() - 1));
  bool grammar_check = true;
  for (size_t it = 0; it < equations.size(); it++)
  {
    equation = equations[it];
    if (it == 0)
    {
      if ((equation.find("program ") == std::string::npos))
      {
        size_t index = equation.find(" ");
        std::string sub = equation.substr(0, index);
        std::cout << "Error on line: " << it + 1
                  << " Did you mean program instead of  " << sub << "\n"
                  << equations[it] << "\n";
        exit(0);
      }
      else if ((*(equation.end() - 1)) != ';')
      {
        std::cout << "Error on line: " << it + 1
                  << " expected ';' after expression.\n"
                  << equations[it] << "\n";
        exit(0);
      }
      else if (it + 1 == 1)
      {
        size_t index = equation.find(" ");
        for (size_t i = index + 1; i < equation.size(); i++)
        {
          if (std::isdigit(equation[i]) && i != 8)
          {
            std::string input(1, equation[i]);
            for (size_t it = 0; it < 10; it++)
            {
              if (digits[it] == input)
              {
                break;
              }
            }
          }
          else if (isalpha(equation[i]))
          {
            std::string input(1, equation[i]);
            for (size_t it = 0; it < 5; it++)
            {
              if (letter[it] == input)
              {
                break;
              }
            }
            continue;
          }

          else if (equation[i] == ';')
          {
            continue;
          }
          else
          {
            std::cout << "Error on line: " << it + 1
                      << " The variable should starts with letter  " << equation
                      << "\n"
                      << equations[it] << "\n";
            exit(0);
          }
          continue;
        }
      }
      continue;
    }
    else if (it == 1)
    {
      if ((equation.find("var") == std::string::npos))
      {
        std::cout << "Error on line: " << it + 1
                  << " Did you mean var instead of  " << equation << "\n"
                  << equations[it] << "\n";
        exit(0);
      }
      else
      {
        continue;
      }
    }
    else if (it == 2)
    {
      if ((*(equation.end() - 1)) != ';')
      {
        std::cout << "Error on line: " << it + 1
                  << " expected ';' after expression.\n"
                  << equations[it] << "\n";
        exit(0);
      }
      else if ((equation.find(":") == std::string::npos))
      {
        size_t index = equation.find("integer");
        std::string sub = equation.substr(0, index);
        std::string sub2 = equation.substr(index, (*equation.end() - 2));
        std::cout << "Error on line: " << it + 1
                  << " expected ':' after expression.\n\"" << sub
                  << "\" and before this \"" << sub2 << "\"\n";
        exit(0);
      }
      else if ((equation.find("integer") == std::string::npos))
      {
        size_t index = equation.find(":");
        std::string sub = equation.substr(0, index + 2);
        std::cout << "Error on line: " << it + 1
                  << " Did you mean integer instead of  " << sub << "\n"
                  << equation << "\n";
        exit(0);
      }
      else
      {
        std::string var;
        for (size_t i = 0; i < equation.size(); i++)
        {
          if (std::isdigit(equation[i]) && i != 0)
          {
            std::string input(1, equation[i]);
            for (size_t it = 0; it < 10; it++)
            {
              if (digits[it] == input)
              {
                var += std::string(digits[it]);
                break;
              }
            }
          }
          else if (isalpha(equation[i]))
          {
            std::string input(1, equation[i]);
            for (size_t it = 0; it < 5; it++)
            {
              if (letter[it] == input)
              {
                var += std::string(letter[it]);
                break;
              }
            }
          }
          else if (isspace(equation[i]) && equation[i + 1] == ',' &&
                   isspace(equation[i + 2]) &&
                   (isalpha(equation[i + 3]) || equation[i + 3] == ':'))
          {
            var += equation[i + 1];
            i += 2;
            continue;
          }
          else if (isspace(equation[i]) && (equation[i + 1] == ':') &&
                   isspace(equation[i + 2]))
          {
            break;
          }
          else if (equation[i] == ',' && isspace(equation[i + 1]) &&
                   (isalpha(equation[i + 2]) || equation[i + 2] == ':'))
          {
            var += equation[i];
            i++;
            continue;
          }
          else if ((isspace(equation[i])) &&
                   (equation[i + 1] != ',' || isspace(equation[i + 2]) ||
                    isalpha(equation[i + 3])))
          {
            std::cout << "Error on line: " << it + 1
                      << " Missing ',' between the variables declarations "
                      << equation << "\n"
                      << equations[it] << "\n";
            exit(0);
          }
          else
          {
            std::cout << "Error on line: " << it + 1
                      << " The variable should starts with letter  " << equation
                      << "\n"
                      << equations[it] << "\n";
            exit(0);
          }
        }
        size_t index = var.find(",");
        while (index != std::string::npos)
        {

          std::string sub = var.substr(0, index);
          variables.insert(std::pair<std::string, int>(sub, 0));
          var.erase(0, index + 1);
          index = var.find(",");
        }
        variables.insert(std::pair<std::string, int>(var, 0));
      }
    }
    else if (it == 3)
    {
      if ((equation.find("begin") == std::string::npos))
      {
        std::cout << "Error on line: " << it + 1
                  << " Did you mean begin instead of  " << equation << "\n"
                  << equations[it] << "\n";
        exit(0);
      }
      else
      {
        continue;
      }
    }
    else if (line2 != "end.")
    {
      if (line2.find("end") == std::string::npos)
      {
        std::cout << "Error on line: " << equations.size()
                  << " Did you mean end instead of  " << line2 << "\n"
                  << line2 << "\n";
        exit(0);
      }
      else if (line2.find(".") == std::string::npos)
      {
        std::cout << "Error on line: " << equations.size()
                  << " Missing '.' after " << line2 << "\n"
                  << line2 << "\n";
        exit(0);
      }
    }
    else if (*(equations.end() - 1) != equations[it])
    {
      if (equation.find("\"") != std::string::npos)
      {
        if (*(equation.end() - 1) != ';')
        {
          std::cout << "Error on line: " << it + 1
                    << " expected ';' after expression.\n"
                    << equations[it] << "\n";
          exit(0);
        }
        else if (equation.find("(") == std::string::npos)
        {
          std::cout << "Error on line: " << it + 1
                    << " expected '(' after print.\n"
                    << equations[it] << "\n";
          exit(0);
        }
        else if (equation.find(")") == std::string::npos)
        {
          std::cout << "Error on line: " << it + 1
                    << " expected ')' after variable.\n"
                    << equations[it] << "\n";
          exit(0);
        }
        else if (equation.find("print") == std::string::npos)
        {
          std::cout << "Error on line: " << it + 1
                    << " Did you mean print instead of  " << equation << "\n"
                    << equations[it] << "\n";
          exit(0);
        }
        else if (equation.find("\",") == std::string::npos)
        {
          std::cout << "Error on line: " << it + 1 << " Forgot ','   "
                    << equation << "\n"
                    << equations[it] << "\n";
          exit(0);
        }
        size_t index1 = equation.find("\"");
        size_t index = equation.find("\",");
        std::string sub = equation.substr(index1 + 1, (index - 1) - index1);

        size_t s_variable = equation.find(", ");
        size_t e_variable = equation.find(" )");
        std::string sub2 =
            equation.substr(s_variable + 2, (e_variable - 1) - s_variable - 1);
        std::map<std::string, int>::iterator search = variables.find(sub2);
        if (search != variables.end())
        {
          output += sub;
          output += std::to_string(search->second);
          output += '\n';
        }
        else
        {
          std::cout << '\n';
        }
      }
      else if (equation.find("=") != std::string::npos)
      {
        if (*(equation.end() - 1) != ';')
        {
          std::cout << "Error on line: " << it + 1
                    << " expected ';' after expression.\n"
                    << equations[it] << "\n";
          exit(0);
        }
        else if (equation.find("(") != std::string::npos &&
                 equation.find(")") == std::string::npos)
        {
          std::cout << "Error on line: " << it + 1 << " expected ')' at end.\n"
                    << equations[it] << "\n";
          exit(0);
        }
        else if (equation.find(")") != std::string::npos &&
                 equation.find("(") == std::string::npos)
        {
          std::cout << "Error on line: " << it + 1
                    << " expected '(' after variable.\n"
                    << equations[it] << "\n";
          exit(0);
        }
        grammar.push("$");
        grammar.push("A");
        std::string inputed, final2, final, top_of_stack = "S", finding;
        top_of_stack = grammar.top();
        for (size_t it = 0; it < equation.size(); ++it)
        {
          if (isalpha(equation[it]))
          {
            inputed = 'i';
            final += inputed;
          }
          else if (std::isdigit(equation[it]))
          {
            inputed = 'n';
            final += inputed;
          }
          else
          {
            final += equation[it];
          }
        }
        inputed = "";
        for (size_t it = 0; it < final.size(); it++)
        {
          if ((final[it] == 'i') &&
              (final[it + 1] == 'i' || final[it + 1] == 'n') &&
              (final[it + 2] == 'i' || final[it + 2] == 'n') &&
              isspace(final[it + 3]))
          {
            it += 3;
            inputed += 'i';
            continue;
          }
          else if ((final[it] == 'i') &&
                   (final[it + 1] == 'i' || final[it + 1] == 'n'))
          {
            it++;
            inputed += 'i';
            continue;
          }
          else if ((final[it] == '-' && final[it + 1] == 'n'))
          {
            it += 2;
            inputed += 'n';
            continue;
          }
          else if (final[it] == 'n' &&
                   (final[it + 1] == 'n' || isspace(final[it + 1])))
          {
            it++;
            inputed += 'n';
            continue;
          }
          else if (isspace(final[it]))
          {
            continue;
          }
          else
          {
            inputed += final[it];
          }
        }
        final2 = inputed;
        inputed = "";
        final = "";
        for (std::string::iterator its = final2.begin(); its != final2.end();
             ++its)
        {
          inputed = (*its);
          top_of_stack = grammar.top();
          grammar.pop();
          if (top_of_stack == inputed)
          {
            if (top_of_stack == ";")
            {
              if (grammar.top() == "$")
              {
                final += inputed;
                if (final == final2)
                {
                  grammar_check = true;
                }
              }
            }
            else
            {
              final += inputed;
              continue;
            }
          }
          for (size_t i = 0; i < ROW_SIZE; i++)
          {
            if (table[i][0] == top_of_stack && table[i][1] == inputed)
            {
              if (table[i][2] == "λ")
              {
              }
              else if (table[i][2] == "BLANK")
              {
                grammar_check = false;
                std::cout << "Rejected due to problem in your expression on "
                             "line number: "
                          << it + 1 << '\n'
                          << equations[it] << '\n';
                exit(0);
              }
              else
              {
                if (table[i][2].size() == 1)
                {
                  grammar.push(table[i][2]);
                }
                else if (table[i][2].size() == 2)
                {
                  std::string first = table[i][2].substr(0, 1);
                  std::string second = table[i][2].substr(1, 1);
                  grammar.push(second);
                  grammar.push(first);
                }
                else if (table[i][2].size() == 3)
                {
                  std::string first = table[i][2].substr(0, 1);
                  std::string second = table[i][2].substr(1, 1);
                  std::string third = table[i][2].substr(2, 1);
                  grammar.push(third);
                  grammar.push(second);
                  grammar.push(first);
                }
                else if (table[i][2].size() == 4)
                {
                  std::string first = table[i][2].substr(0, 1);
                  std::string second = table[i][2].substr(1, 1);
                  std::string third = table[i][2].substr(2, 1);
                  std::string forth = table[i][2].substr(3, 1);
                  grammar.push(forth);
                  grammar.push(third);
                  grammar.push(second);
                  grammar.push(first);
                }
              }
              --its;
              break;
            }
          }
        }
        if (grammar_check)
        {
          if (equation.find("+") == std::string::npos &&
              equation.find("-") == std::string::npos &&
              equation.find("*") == std::string::npos &&
              equation.find("/") == std::string::npos)
          {
            size_t index = equation.find(" = ");
            std::string sub = equation.substr(0, index);
            std::string sub2 = equation.substr(index + 3, 1);
            std::map<std::string, int>::iterator found = variables.find(sub);
            if (found != variables.end())
            {
              found->second = std::stoi(sub2);
            }
          }
          else
          {
            std::string assign;
            inputed = "";
            size_t index = equation.find("(");
            if (index != std::string::npos)
            {
              inputed = "";
              size_t index2 = equation.find(" = ");
              assign = equation.substr(0, index2);
              std::string sub =
                  equation.substr(index2 + 3, ((index - 4) - (index2)));
              for (size_t i = 0; i <= sub.size(); i++)
              {
                if (isspace(sub[i]))
                {
                  if ((sub[i] == '-' && std::isdigit(sub[i + 1])))
                  {
                    std::cout << inputed << '\n';
                    inputed = sub[i] + sub[i + 1];
                    std::cout << inputed << '\n';
                    expression.push(inputed);
                    inputed = "";
                    i += 2;
                  }
                  else if (std::isdigit(sub[i]))
                  {
                    expression.push(inputed);
                  }
                  std::map<std::string, int>::iterator found =
                      variables.find(inputed);
                  if (found != variables.end())
                  {
                    expression.push(std::to_string(found->second));
                    inputed = "";
                  }
                }
                else if (sub[i] == '+' || sub[i] == '-' || sub[i] == '*' ||
                         sub[i] == '/')
                {
                  inputed += sub[i];
                  expression.push(inputed);
                  inputed = "";
                }
                else
                {
                  inputed += sub[i];
                }
              }
              inputed = "";
              index2 = equation.find(")");
              sub = equation.substr(index + 2, (index2 - 2 - index));
              for (size_t i = 0; i <= sub.size(); ++i)
              {
                if (isspace(sub[i]) || (sub[i + 1] == *(sub.end())))
                {
                  if (std::isdigit(inputed[0]) || inputed[0] == '-')
                  {
                    expression.push(inputed);
                    inputed = "";
                  }
                  else if (sub[i + 1] == *(sub.end()))
                  {
                    inputed += sub[i];
                    std::map<std::string, int>::iterator found =
                        variables.find(inputed);
                    if (found != variables.end())
                    {
                      expression.push(std::to_string(found->second));
                      inputed = "";
                    }
                  }
                  else
                  {
                    std::map<std::string, int>::iterator found =
                        variables.find(inputed);
                    if (found != variables.end())
                    {
                      expression.push(std::to_string(found->second));
                      inputed = "";
                    }
                  }
                }
                else if ((sub[i] == '+' || sub[i] == '-' || sub[i] == '*' ||
                          sub[i] == '/') &&
                         isspace(sub[i + 1]))
                {
                  inputed += sub[i];
                  expression.push(inputed);
                  inputed = "";
                  i++;
                }
                else
                {
                  inputed += sub[i];
                }
              }
            }
            inputed = expression.top();
            int answer;
            expression.pop();
            while (!expression.empty())
            {

              top_of_stack = expression.top();

              if (top_of_stack == "+")
              {
                expression.pop();
                int first = stoi(inputed);
                top_of_stack = expression.top();
                int second = stoi(top_of_stack);
                answer = second + first;
                inputed = std::to_string(answer);
                expression.push(inputed);
              }
              else if (top_of_stack == "-")
              {
                expression.pop();
                int first = stoi(inputed);
                top_of_stack = expression.top();
                int second = stoi(top_of_stack);
                answer = second - first;
                inputed = std::to_string(answer);
                expression.push(inputed);
              }
              else if (top_of_stack == "*")
              {
                expression.pop();
                int first = stoi(inputed);
                top_of_stack = expression.top();
                int second = stoi(top_of_stack);
                answer = second * first;
                inputed = std::to_string(answer);
                expression.push(inputed);
              }
              else if (top_of_stack == "/")
              {
                expression.pop();
                int first = stoi(inputed);
                top_of_stack = expression.top();
                int second = stoi(top_of_stack);
                answer = second / first;
                inputed = std::to_string(answer);
                expression.push(inputed);
              }
              expression.pop();
            }
            std::map<std::string, int>::iterator found = variables.find(assign);
            if (found != variables.end())
            {
              found->second = stoi(inputed);
            }
          }
        }
        /*else {
          std::cout << "rejected" << '\n';
        }*/
      }
      else if (equation.find("print") != std::string::npos)
      {
        if (*(equation.end() - 1) != ';')
        {
          std::cout << "Error on line: " << it + 1
                    << " expected ';' after expression.\n"
                    << equations[it] << "\n";
          exit(0);
        }
        else if (equation.find("(") == std::string::npos)
        {
          size_t index = equation.find("\"");
          std::string sub = equation.substr(0, index);
          std::cout << "Error on line: " << it + 1 << " expected '(' after "
                    << sub << ".\n"
                    << equations[it] << "\n";
          exit(0);
        }
        else if (equation.find(")") == std::string::npos)
        {
          std::cout << "Error on line: " << it + 1
                    << " expected ')' after variable.\n"
                    << equations[it] << "\n";
          exit(0);
        }
        else
        {
          size_t index = equation.find("(");
          size_t index2 = equation.find(")");
          std::string sub = equation.substr(index + 1, (index2 - 2) - index);
          std::map<std::string, int>::iterator search = variables.find(sub);
          if (search != variables.end())
          {
            output += std::to_string(search->second);
          }
          else
          {
            std::cout << "Error on line: " << it + 1
                      << " undeclared variable. \n"
                      << equations[it] << '\n';
            exit(0);
          }
        }
      }
      else if (equation.find("print") == std::string::npos)
      {
        std::cout << "Error on line: " << it + 1
                  << " Did you mean print instead of  " << equation << "\n"
                  << equations[it] << "\n";
        exit(0);
      }
    }
  }
  if (grammar_check)
  {
    std::cout << "Accepted\n";
    std::cout << output;
  }
  return 0;
}

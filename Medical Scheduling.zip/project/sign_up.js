const options = document.querySelector('.practice_option');
const username = document.querySelector('.username');
const password = document.querySelector('.password');
const email = document.querySelector('.email');
const street_name = document.querySelector('.street_name');
const suite_number = document.querySelector('.Apt');
const city = document.querySelector('.city');
const state = document.querySelector('.state');
const zip = document.querySelector('.zipcode');
const practice = document.querySelector('.practice_option');
const body = document.querySelector('.body');
const button = document.querySelector('.button');
const forms = document.querySelector('form');
const preference_by_checkbox = document.querySelector(".preference_by_checkbox");
const error = document.querySelector('.error');
let preference_data;
practice.addEventListener("change", function () {
    // this addenventlistener will generate other input field for custom user input
    if (options.value === 'Other') {
        const input = document.createElement('input');
        input.setAttribute('name', 'other');
        input.setAttribute('id', 'others');
        input.setAttribute('type', 'text');
        input.setAttribute('class', 'other_input');
        input.setAttribute('placeholder', 'other');
        forms.appendChild(input);

    }
    else {
        let input = document.getElementById('others');
        if (input != null && options.value != 'Other') {
            let other = document.getElementById('others');
            forms.removeChild(other);
        }
    }
});

function row() {
    // this function will generate all the practice for user to select from dropdown options. 
    let oldOption = new Option('None', 'None', 'disabled selected');
    options.appendChild(oldOption, undefined);
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "drop_down.php", true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.onload = function () {
        let data = JSON.parse(xhr.responseText)
        data.map((result) => {
            let name = new Option(result.practice, result.practice);
            options.appendChild(name, undefined)
                
        });
        row2(data)
    }
    let second = new Option('Other', 'Other')
    options.appendChild(second, undefined)

    xhr.send()
}

function row2(data) {
    // this functions will generate all the practice as checkbox for user to select multiple as preference.
    let html = "";
    preference_data = data;
    for (let i = 0; i < data.length; i++) {
        html += `<input type="checkbox" name="preference[]" class="preference" value="${data[i].practice}"> <label>${data[i].practice}<br></label>`;   
    }
    html += `<button type="button" class="select" onclick="select_all()">Select All</button>
    <button type="button" class="clear" onclick="clear_all()">Clear All</button>`;
    preference_by_checkbox.innerHTML = html;

}
function select_all() {
    // This function will select all preferences
    for (let i = 0; i < preference_data.length; i++) { 
        const to_select = document.getElementsByClassName("preference");
        if(to_select[i].type=='checkbox')  {
            to_select[i].checked=true;  
        }  
   }
}
function clear_all() {
    // This function will clear all preferences
    for (let i = 0; i < preference_data.length; i++) { 
        const to_select = document.getElementsByClassName("preference");
        if(to_select[i].type=='checkbox')  {
            to_select[i].checked=false;  
        }  
   }
}
function insert() {
    // This function will check for the input.
    let usernames = username.value;
    let emails = email.value;
    let passwords = password.value;
    let street_names = street_name.value;
    let suite_numbers = suite_number.value;
    let cities = city.value;
    let states = state.value;
    let zipcode = zip.value;
    let practices = practice.value;
    let values = new Array;
    
    if (usernames.length > 0 && emails.length > 0 && passwords.length > 0
        && street_names.length > 0 && cities.length > 0 && states.length && zipcode.length > 0) {
        document.querySelector('form').submit();
    }

}
let show = true;

function showCheckboxes() {
    let checkboxes =
        document.getElementById("checkBoxes");

    if (show) {
        checkboxes.style.display = "block";
        show = false;
    } else {
        checkboxes.style.display = "none";
        show = true;
    }
}
function error_check() {
    if (document.location.href.indexOf("?") != -1) {
        error.style.setProperty('--hidden', 'visible');
        error.style.setProperty('--none', 'block');
    } 
}
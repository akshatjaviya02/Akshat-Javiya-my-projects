
const tables = document.querySelector(".emails");
const email = document.querySelector(".email");
const go_back_btn = document.querySelector(".go_back");
const name = document.querySelector(".names");
const subject = document.querySelector(".subjects");
const important = document.querySelector(".importants");
const reply = document.querySelector(".reply");
const reply_emails = document.querySelector(".reply-message");
let new_id = 0;
let all_data;
let sent_data;
let reply_array;
let username;
let reply_id = 0;
window.onload = function () {
    row();
    emails();
    sent_emails();
    // For times when provider.html passes the usernames to directly email the person.
    if (document.location.href.indexOf("?") != -1) {
        let url = document.location.href,
            params = url.split('?')[1].split('&'),
            data = {}, tmp;
        for (let i = 0, l = params.length; i < l; i++) {
            tmp = params[i].split('=');
            data[tmp[0]] = tmp[1];
        }
        username = data.username;
        new_message_with_values(username)
    }
    
    
};
function new_message_with_values(username) {
    // For times when provider.html passes the usernames to directly email the person.
    tables.style.setProperty("--hidden", "visible");
    tables.style.setProperty("--none", "block");
    let html = `
        <form action="new_message.php" method="POST">
            <input type="text" class="usernames" placeholder="example" name="username" value="${username}">            
            <input type="text" class="subjects" placeholder="subject" name="subject">
            <textarea type="text" class="messages" placeholder="message" name="message"> </textarea>
            <button type="submit" class="submit" onclick="verify_new_message()">Send</> 
        </form>
    `;
    tables.innerHTML = html;
}
function display_reply_box() {
    // displays reply box for the input.
    reply.style.setProperty("--hidden", "visible");
    reply.style.setProperty("--none", "block");
    let html = `
    <form action="reply.php" method="POST">
        <textarea type="text" class="reply_messages" placeholder="message" name="message"> </textarea>
        <input type="hidden" name="message_id" value="${reply_id}" />
        </form>
    <button type="submit" class="submit2" onclick="verify_reply()">Send</button> 
    <button type="button" class="cancel" onclick="hide_reply_div()"> Cancel </button>
    `;
    reply.innerHTML = html;
}
function verify_reply() {
    // verify reply input field.
    let message = document.querySelector(".reply_messages");
    let forms = document.querySelector("form");
    if (message.value.length > 0) {
        forms.submit()
    }
}
function hide_reply_div() {
    // if the reply div is hidden, until the button is clicked.
    reply.innerHTML = `<button type="button" class="reply" onclick="display_reply_box()">reply</button>`
}
function row() {
    // autentication of user
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "authenication.php", true);
    xhr.onload = function () {
        if(xhr.responseText == "sucess") {
            login_button.remove();
            sign_up.remove();

            const li4 = document.createElement("li");
            const href4 = document.createElement("a");
            href4.setAttribute("href", "view booking.html");
            let t4 = document.createTextNode("View Bookings");
            href4.appendChild(t4);
            li4.appendChild(href4);
            nav_links.insertBefore(li4, directions);

            const li5 = document.createElement("li");
            const href5 = document.createElement("a");
            href5.setAttribute("href", "provider.html");
            let t5 = document.createTextNode("Find Provider");
            href5.appendChild(t5);
            li5.appendChild(href5);
            nav_links.insertBefore(li5, directions);

            const li3 = document.createElement("li");
            const href3 = document.createElement("a");
            href3.setAttribute("href", "schedule.html");
            let t3 = document.createTextNode("Schedule Meeting");
            href3.appendChild(t3);
            li3.appendChild(href3);
            nav_links.insertBefore(li3, directions);

            const li = document.createElement("li");
            const href = document.createElement("a");
            href.setAttribute("href", "edit-profile.html");
            let t = document.createTextNode("Edit Profile");
            href.appendChild(t);
            li.appendChild(href);
            nav_links.appendChild(li);

            const li2 = document.createElement("li");
            const href2 = document.createElement("a");
            href2.setAttribute("href", "inbox.html");
            let t2 = document.createTextNode("Inbox");
            href2.appendChild(t2);
            li2.appendChild(href2);
            nav_links.appendChild(li2);
            
            const li1 = document.createElement("li");
            const href1 = document.createElement("a");
            href1.setAttribute("href", "logout.php");
            let t1 = document.createTextNode("Logout");
            href1.appendChild(t1);
            li1.appendChild(href1);
            nav_links.appendChild(li1);
        }
        else {
            window.location.href = "login.html";
        }
    };
    xhr.send();
}

function emails() {
    // gets the data from database about the user being in recieving side.
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "inbox.php", true);
    xhr.onload = function () {
        if (xhr.responseText == "error: no messages") {
            console.log(xhr.responseText);
            all_data = "No messages are available.";
            //sends to set data 
            set_data(all_data)
        }
        else {
            let data = JSON.parse(xhr.response);
            set_data(data);
            
        }

    }
    xhr.send();
}
function set_data(data) {
    // this will set the data to all data varaible.
    all_data = data;
    // the users is not using the feed username technique then it will generate emails to the page.
    if (document.location.href.indexOf("?") == -1) {
        generate_html();
    }
}
function Mark_Important_email() {
    // This function gets the values in the arrays which are important and passes to important_emails.php to update database and updates the all_data variable by calling emails function again. 
    let values = new Array;
    const selected = document.getElementsByName("email")
    for (let i = 0; i < selected.length; i++) {
        if (selected[i].checked) {
            values.push(selected[i].value);
        }
    }
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "important_emails.php", true);
    xhr.onload = function () {
        if (xhr.responseText == "Error") {
            console.log(xhr.responseText);
        }
        else {
            emails();
        }

    }
    xhr.send(JSON.stringify({ "important": values }));
}
function generate_html() {
    // this function will genrate all the emails to the page.
    reply.style.setProperty("--hidden", "invisible");
    reply.style.setProperty("--none", "none");
    tables.style.setProperty("--hidden", "visible");
    tables.style.setProperty("--none", "block");
    important.style.setProperty("--hidden", "visible");
    important.style.setProperty("--none", "block");
    email.style.setProperty("--hidden", "invisible");
    email.style.setProperty("--none", "none");
    let html = "";
    if (all_data == "No messages are available.") {
        tables.innerHTML = all_data;
        return ;
    }
    else {
        for (let i = 0; i < all_data.length; i++) {
            if (all_data[i].seen == "0") {
                if (all_data[i].important == "0") {
                    html += `
                    <div class="email-row">
                        <div class="items">
                        <input type="checkbox" name="email" value=${all_data[i].id} />
                            <a class="message" href="javascript:void(0);" onclick="get_replies(${all_data[i].id})">
                                <h5 class="name">${all_data[i].sender_name}</h5>
                                <h5 class="subject">${all_data[i].subject}</h5>
                                <h5 class="message">- ${all_data[i].message.slice(0, 20)}...</h5>
                                <h5 class="time">${all_data[i].sent_time.slice(0, 10)}</h5>   
                            </a>
                        </div>
                    </div>
                    `;
                }
                else if (all_data[i].important == "1") {
                    html += `
                    <div class="email-row">
                        <div class="items">
                        <input type="checkbox" name="email" value=${all_data[i].id} />
                            <a class="message" href="javascript:void(0);" onclick="get_replies(${all_data[i].id})">
                                <h5 class="name">${all_data[i].sender_name}</h5>
                                <h5 class="subject">${all_data[i].subject}</h5>
                                <h5 class="message">- ${all_data[i].message.slice(0, 20)}...</h5>
                                <h5 class="time">${all_data[i].sent_time.slice(0, 10)}</h5> 
                                <h5 class="important">Important!</h5>
                            </a>
                        </div>
                    </div>
                    `;
                }
            }
        }
        if (html.length == 0) {
            html = `<h5 class="no_message">No new messages are available.</h5>`;
        }
        tables.innerHTML = html;
    }
}
function sent_emails() {
    // This function will get all the emails that are sent by current users
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "sent_emails.php", true);
    xhr.onload = function () {
        if (xhr.responseText == "error: no messages") {
            console.log(xhr.responseText);
            sent_data = "No messages are sent.";
        }
        else {
            let data = JSON.parse(xhr.response);
            sent_data = data;
        }
    }
    xhr.send();
}
function generate_sent_emails() {
    //this function displays all the sent emails to html
    reply_emails.style.setProperty("--hidden", "invisible");
    reply_emails.style.setProperty("--none", "none");
    reply.style.setProperty("--hidden", "invisible");
    reply.style.setProperty("--none", "none");
    tables.style.setProperty("--hidden", "visible");
    tables.style.setProperty("--none", "block");
    important.style.setProperty("--hidden", "visible");
    important.style.setProperty("--none", "block");
    email.style.setProperty("--hidden", "invisible");
    email.style.setProperty("--none", "none");
    let html = "";
    if (sent_data == "No messages are sent.") {
        tables.innerHTML = "No messages are sent.";
    }
    else {
        for (let i = 0; i < sent_data.length; i++) {
            html += `
                <div class="email-row">
                    <div class="items">
                    <input type="checkbox" name="email" value=${sent_data[i].id} />
                        <a class="message" href="javascript:void(0);" onclick="display_sent_email(${sent_data[i].id})">
                            <h5 class="name">${sent_data[i].receiver_name}</h5>
                            <h5 class="subject">${sent_data[i].subject}</h5>
                            <h5 class="message">- ${sent_data[i].message.slice(0, 20)}...</h5>
                            <h5 class="time">${sent_data[i].sent_time.slice(0, 10)}</h5>   
                        </a>
                    </div>
                </div>
                `;
        }
        tables.innerHTML = html;
    }
}
function new_message() {
    // function will display new message input fields to html.
    reply.style.setProperty("--hidden", "invisible");
    reply.style.setProperty("--none", "none");
    let html = `
        <form action="new_message.php" method="POST">
            <input type="text" class="usernames" placeholder="example" name="username">            
            <input type="text" class="subjects" placeholder="subject" name="subject">
            <textarea type="text" class="messages" placeholder="message" name="message"> </textarea>
            <button type="submit" class="submit" onclick="verify_new_message()">Send</> 
        </form>
    `;
    tables.innerHTML = html;
}

function verify_new_message() {
    // verify new message input fields
    const username = document.querySelector(".username");
    const subject = document.querySelector(".subject");
    const message = document.querySelector(".message");
    if (username.length > 0 && subject.length > 0 && message.length > 0) {
        document.querySelector("form").submit();
    }
}
function display_sent_email(id) {
    // this function diplays email to the html page after user clicked on the email.
    new_id = id;
    reply.style.setProperty("--hidden", "invisible");
    reply.style.setProperty("--none", "none");
    go_back_btn.style.setProperty("--hidden", "visible");
    go_back_btn.style.setProperty("--none", "block");
    important.style.setProperty("--hidden", "invisible");
    important.style.setProperty("--none", "none");
    tables.style.setProperty("--hidden", "invisible");
    tables.style.setProperty("--none", "none");
    email.style.setProperty("--hidden", "visible");
    email.style.setProperty("--none", "block");
    let result = sent_data.find(({ id }) => id === new_id);
    let message = result.message.replace(/\r\n/gi, "<br>");
    let html = `
        <h3 class="sender">Reciever: ${result.receiver}</h3>
        <h3 class="sender_name">Receiver Name: ${result.receiver_name} </h3> 
        <h3 class="sent_time">${result.sent_time.slice(0, 10)}</h3> 
        <h3 class="subjects">${result.subject}</h3>
        
        <h3 class="messages">${message}</h3>
    `;
    email.innerHTML = html;
}
function all_mails() {
    // displays all the emails that were seen by users and not seen by users.
    reply.style.setProperty("--hidden", "invisible");
    reply.style.setProperty("--none", "none");
    tables.style.setProperty("--hidden", "visible");
    tables.style.setProperty("--none", "block");
    important.style.setProperty("--hidden", "visible");
    important.style.setProperty("--none", "block");
    email.style.setProperty("--hidden", "invisible");
    email.style.setProperty("--none", "none");
    let html = "";
    if (all_data == "No messages are available.") {
        tables.innerHTML = all_data
    }
    else {
        for (let i = 0; i < all_data.length; i++) {
            if (all_data[i].important == "0") {
                html += `
                <div class="email-row">
                    <div class="items">
                    <input type="checkbox" name="email" value=${all_data[i].id} />
                        <a class="message" href="javascript:void(0);" onclick="get_replies(${all_data[i].id}); display_email(${all_data[i].id});">
                            <h5 class="name">${all_data[i].sender_name}</h5>
                            <h5 class="subject">${all_data[i].subject}</h5>
                            <h5 class="message">- ${all_data[i].message.slice(0, 20)}...</h5>
                            <h5 class="time">${all_data[i].sent_time.slice(0, 10)}</h5>   
                        </a>
                    </div>
                </div>
                `;
            }
            else if (all_data[i].important == "1") {
                html += `
                <div class="email-row">
                    <div class="items">
                    <input type="checkbox" name="email" value=${all_data[i].id} />
                        <a class="message" href="javascript:void(0);" onclick="get_replies(${all_data[i].id}); display_email(${all_data[i].id});">
                            <h5 class="name">${all_data[i].sender_name}</h5>
                            <h5 class="subject">${all_data[i].subject}</h5>
                            <h5 class="message">- ${all_data[i].message.slice(0, 20)}...</h5>
                            <h5 class="time">${all_data[i].sent_time.slice(0, 10)}</h5> 
                            <h5 class="important">Important!</h5>
                        </a>
                    </div>
                </div>
                `;
            }
        }
        tables.innerHTML = html;
    }
}
function Important_email() {
    // this function displays the important emails to html page.
    reply_emails.style.setProperty("--hidden", "invisible");
    reply_emails.style.setProperty("--none", "none");
    reply.style.setProperty("--hidden", "invisible");
    reply.style.setProperty("--none", "none");
    tables.style.setProperty("--hidden", "visible");
    tables.style.setProperty("--none", "block");
    email.style.setProperty("--hidden", "invisible");
    email.style.setProperty("--none", "none");
    go_back_btn.style.setProperty("--hidden", "invisible");
    go_back_btn.style.setProperty("--none", "none");
    important.style.setProperty("--hidden", "visible");
    important.style.setProperty("--none", "block");
    let html = "";
    if (all_data == "No messages are available.") {
        tables.innerHTML = "No important messages are marked.";
    }
    else {
        for (let i = 0; i < all_data.length; i++) {
            if (all_data[i].important == "1") {
                html += `
                <div class="email-row">
                <div class="items">
                <input type="checkbox" name="email" value=${all_data[i].id}>
                    <a class="message" href="javascript:void(0);" onclick="get_replies(${all_data[i].id})">
                        <h5 class="name">${all_data[i].sender_name}</h5>
                        <h5 class="subject">${all_data[i].subject}</h5>
                        <h5 class="message">- ${all_data[i].message.slice(0, 20)}...</h5>
                        <h5 class="time">${all_data[i].sent_time.slice(0, 10)}</h5> 
                        <h5 class="important">Important!</h5>
                    </a>
                </div>
            </div>
            `;
            }
        }
        tables.innerHTML = html;
    }
}
function get_replies(id) {
    // This function will get the reply related to the message id.
    reply_id = id;
    new_id = id;
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "get_reply.php", true);
    xhr.onload = function () {
        if (xhr.responseText === "error: no replies for this message") {
            reply_array = "no replies for this message";
            display_email(reply_array);

        }
        else {
            let data = JSON.parse(xhr.response);
            display_email(data);
        }
    }
    
    xhr.send(JSON.stringify({"id": reply_id}))
}
function display_email(data) {
    // This function will display specific email which is clicked on.
    reply_array = data
    reply.style.setProperty("--hidden", "visible");
    reply.style.setProperty("--none", "block");
    reply_emails.style.setProperty("--hidden", "visible");
    reply_emails.style.setProperty("--none", "block");
    important.style.setProperty("--hidden", "invisible");
    important.style.setProperty("--none", "none");
    go_back_btn.style.setProperty("--hidden", "visible");
    go_back_btn.style.setProperty("--none", "block");
    tables.style.setProperty("--hidden", "invisible");
    tables.style.setProperty("--none", "none");
    let result = all_data.find(({ id }) => id === new_id);
    email.style.setProperty("--hidden", "visible");
    let message = result.message.replace(/\r\n/gi, "<br>");
    email.style.setProperty("--none", "block");
    let html = "";
    html = `
        <h3 class="sender">Sender: ${result.sender}</h3>
        <h3 class="sender_name">Sender Name: ${result.sender_name} </h3> 
        <h3 class="sent_time">${result.sent_time.slice(0, 10)}</h3> 
        <h3 class="subjects">${result.subject}</h3>
        <h3 class="messages">${message}</h3>
    `;
    if (reply_array == "no replies for this message") {
        console.log("No replies for this message");
    
    }
    else {
        let reply_html = "";
        for (let i = 0; i < reply_array.length; i++) {
            let message = reply_array[i].message.replace(/\r\n/gi, "<br>");
            reply_html += `<h4 class="sender2"> Sender username: ${reply_array[i].reciever}</h4>
            <h4 class="time">${reply_array[i].sent_time.slice(0, 10)}</h4>
            <h4 class="message">${message}</h4>
            `;
        }
        reply_emails.innerHTML = reply_html;
    }
    email.innerHTML = html;
    if (result.seen == 0) {
        let xhr = new XMLHttpRequest();
        xhr.open("POST", "seen_email.php", true);
        xhr.onload = function () {
            if (xhr.responseText == "success") {
                for (let i = 0; i < all_data.length; i++) {
                    if (all_data[i].id == new_id) {
                        all_data[i].seen = 1;
                    }
                }
            }
        }
        xhr.send(JSON.stringify({"id": new_id }));
    }
}
function back_page() {
    // this fuction will hide the back button, display important button and call generate_email function to display all emails.
    reply_emails.style.setProperty("--hidden", "invisible");
    reply_emails.style.setProperty("--none", "none");
    go_back_btn.style.setProperty("--hidden", "invisible");
    go_back_btn.style.setProperty("--none", "none");
    important.style.setProperty("--hidden", "visible");
    important.style.setProperty("--none", "block");
    tables.style.setProperty("--hidden", "visible");
    tables.style.setProperty("--none", "block");
    email.style.setProperty("--hidden", "invisible");
    email.style.setProperty("--none", "none");
    generate_html()
}

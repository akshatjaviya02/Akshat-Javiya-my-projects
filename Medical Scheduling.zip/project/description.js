const body2 = document.querySelector(".body2");
const goback = document.querySelector(".back");
const description = document.querySelector(".description_part");
const remove_btn = document.querySelector(".remove");
const book_btn = document.querySelector(".book");
const confirm_div = document.querySelector(".confirm-div");
const login_button = document.querySelector(".login");
const sign_up = document.querySelector(".logins");
const nav_links = document.querySelector(".nav_links");
const directions = document.querySelector(".directions");
let new_id = 0;

function row() {
    // authentication with php session if the session is active then users can see more options
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "authenication.php", true);
    xhr.onload = function () {
        if(xhr.responseText == "sucess") {
            login_button.remove();
            sign_up.remove();

            const li4 = document.createElement("li");
            const href4 = document.createElement("a");
            href4.setAttribute("href", "view booking.html");
            let t4 = document.createTextNode("View Bookings");
            href4.appendChild(t4);
            li4.appendChild(href4);
            nav_links.insertBefore(li4, directions);

            const li3 = document.createElement("li");
            const href3 = document.createElement("a");
            href3.setAttribute("href", "schedule.html");
            let t3 = document.createTextNode("Schedule Meeting");
            href3.appendChild(t3);
            li3.appendChild(href3);
            nav_links.insertBefore(li3, directions);

            const li = document.createElement("li");
            const href = document.createElement("a");
            href.setAttribute("href", "edit-profile.html");
            let t = document.createTextNode("Edit Profile");
            href.appendChild(t);
            li.appendChild(href);
            nav_links.appendChild(li);

            const li2 = document.createElement("li");
            const href2 = document.createElement("a");
            href2.setAttribute("href", "inbox.html");
            let t2 = document.createTextNode("Inbox");
            href2.appendChild(t2);
            li2.appendChild(href2);
            nav_links.appendChild(li2);
            
            const li1 = document.createElement("li");
            const href1 = document.createElement("a");
            href1.setAttribute("href", "logout.php");
            let t1 = document.createTextNode("Logout");
            href1.appendChild(t1);
            li1.appendChild(href1);
            nav_links.appendChild(li1);
        }
        else {
            window.location.href = "login.html";
        }
    };
    xhr.send();
    
}
window.onload = function () {
    row();
    // This gets the event id from the href 
    let url = document.location.href,
        params = url.split('?')[1].split('&'),
        data = {}, tmp;
    for (let i = 0, l = params.length; i < l; i++) {
         tmp = params[i].split('=');
         data[tmp[0]] = tmp[1];
    }
    // assign the id to a variable
    new_id = data.event_id;
    book_btn.disabled = false;
    // calls the events function
    events();
    // calls the remove button function
    remove_button();
};
function events() {
    // passes the specified event id to the specific_event.php as json object this data is the information of the event 
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "specific_event.php", true);
    xhr.onload = function() {
        let data = JSON.parse(xhr.responseText);
        generateHTML(data);
    }
    xhr.send(JSON.stringify({"id": new_id}));
}
function remove_button() {
    // it will display the remove button if the user logged in is the same as owner of the event. Function passes the event id to the specific_event.php as json object.
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "description.php", true);
    xhr.onload = function() {
        if(xhr.responseText == "success") {
            remove_btn.style.setProperty('--hidden', 'visibile');
            remove_btn.style.setProperty('--none', 'block');
        }
        else {
            book_btn.style.setProperty('--hidden', 'invisibile');
            book_btn.style.setProperty('--none', 'block');
        }
    }
    xhr.send(JSON.stringify({"id" : new_id}));
}
function confirm() {
    // display the confirm if you are sure to book the event.
    confirm_div.style.setProperty('--hidden', 'visibile');
    confirm_div.style.setProperty('--none','block');
}
function cancel_book() {
    // the cancel_book hide the confirm_div
    confirm_div.style.setProperty('--none','none');
    confirm_div.style.setProperty('--hidden', 'invisibile');
}
function book_event() {
    // book event function passes the event id to the booking.php as json object. where it will book the event under your name.
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "booking.php", true);
    xhr.onload = function() {
        // if there is any error then it will display error message.
        if(xhr.responseText == "error") {
            let v = document.createElement("p");
            v.setAttribute("class", "removed");
            let text = document.createTextNode("Error occurred")
            v.appendChild(text);
            body2.appendChild(v);
        }
        else if (xhr.responseText == "success") {
            // if there is any error then it will display successful message.
            let v = document.createElement("p");
            v.setAttribute("class", "removed");
            let text = document.createTextNode("Sucessfully Booked")
            v.appendChild(text);
            body2.appendChild(v);
            book_btn.disabled = true;
        }
    }
    xhr.send(JSON.stringify({"id" : new_id}));
}
function remove_event() {
    // this function will remove the event from the database and would display success message.
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "remove_events.php", true);
    xhr.onload = function() {
        if(xhr.responseText == "Success") {
            let v = document.createElement("p");
            v.setAttribute("class", "removed");
            let text = document.createTextNode("Successfully removed event")
            v.appendChild(text);
            body2.appendChild(v);
        }
    }
    xhr.send(JSON.stringify({"id" : new_id}));
}
function generateHTML(data) {
    // this function will generate HTML from data from specific_event.php to html so users can view the description.
    let generatedHTML = "";
    generatedHTML += `
        <p class="description"> 
            Company: ${data.company} <br>
            Person's Name: ${data.name} <br>
            Start Time: ${data.start_time.slice(0, 16)} <br>
            End Time: ${data.end_time.slice(0, 16)} <br>
            Description: ${data.description} <br>
            Food Preferences: ${data.food} <br>
            Location: ${data.location} <br>
        </p>
    `;
    description.innerHTML = generatedHTML;

}


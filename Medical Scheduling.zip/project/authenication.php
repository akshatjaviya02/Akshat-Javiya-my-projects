<?php
    include 'connection.php';
    session_start();
    // To check whether session is active or not
    if ($_SESSION['status'] == 1) {
        echo "sucess";
    }
    else if ($_SESSION['status'] == 0) {
        echo "error";
    }
?>
<?php
    session_start();
    include 'connection.php';
    // this query will return user information for edit profile page
    $query = "SELECT * FROM Login WHERE ID = :id;";
    $stmt = $pdo->prepare($query);
    $stmt->execute(['id' => $_SESSION['id']]);
    $result = $stmt->fetchAll();
    $information = array();
    if(count($result) > 0) {
        $information['id'] = $result[0]->ID;
        $information['username'] = $result[0]->username;
        $information['email'] = $result[0]->email;
        $information['name'] = $result[0]->Name;
        $information['company'] = $result[0]->Company;
        $information['street'] = $result[0]->street_name;
        if ($result[0]->Apt !== null) { 
            $information['apt'] = $result[0]->Apt;
        }
        else {
            $information['apt'] = $result[0]->Apt;
        }
        $information['city'] = $result[0]->City;
        $information['state'] = $result[0]->State;
        $information['zip'] = $result[0]->zipcode;
        $information['practice'] = $result[0]->practice;
        $information['provider'] = $result[0]->provider;
        $preference = unserialize($result[0]->preference);
        $information['preference'] = $preference;
        $information['urgency'] = $result[0]->urgency;
    }
    echo json_encode($information, JSON_PRETTY_PRINT);
?>
<?php
    session_start();
    include 'connection.php';
    $options = [
        'cost' => 12,
    ];
    // checks if there is another email under same email id.
    $query2 = "SELECT * FROM Login WHERE email= :email;";
    $stmt2 = $pdo->prepare($query2);
    $stmt2->execute(["email" => $_POST['email']]);
    $results = $stmt2->fetchAll();
    // If yes the results are more than 0 then will throw return with invalid
    if (count($results) > 0) { 
        header("Location: sign_up.html?error=invaild");
        exit();
    }
    else {
        $array = serialize($_POST['preference']);
        // hash the password
        $hashed_password = password_hash($_POST['password'], PASSWORD_BCRYPT, $options);
        $practice = "";
        if ($_POST['other'] != '') {
            $practice = $_POST['other'];
        }
        else {
            $practice = $_POST['practice'];
        }
        // if the suite number is 0 then use this if part 
        if (strlen($_POST['suite_number']) == 0) {
            $query = "INSERT INTO `Login` (`username`, `email`, `password`, `Company`, `Name`, `street_name`, `City`, `State`, `zipcode`, `provider`, `practice`, `preference`, `urgency`) VALUES (:username, :email, :password, :company, :name, :street, :city, :state, :zip, :provider, :practice, :preference, :urgency)";
            $stmt = $pdo->prepare($query);
            $stmt->execute(["username" => $_POST['username'], "email" => $_POST['email'], "password" => $hashed_password, "company" => $_POST['company'], "name" => $_POST['name'], "street" => $_POST['address'], "city" => $_POST['city'], "state" => $_POST['state'], "zip" => $_POST['zipcode'], "provider" => $_POST['provider'], "practice" => $practice, "preference" => $array, "urgency" => $_POST['urgency']]);
            $last_id = $pdo->lastInsertId();
            echo $array;
    
        }
        else {
            // use this else if the suite number is not 0.
            $query = "INSERT INTO `Login` (`username`, `email`, `password`, `Company`, `Name`, `street_name`, `Apt`, `City`, `State`, `zipcode`, `provider`, `practice`, `preference`, `urgency`) VALUES (:username, :email, :password, :company, :name, :street, :apt, :city, :state, :zip, :provider, :practice, :preference, :urgency)";
            $stmt = $pdo->prepare($query);
            $stmt->execute(["username" => $_POST['username'], "email" => $_POST['email'], "password" => $hashed_password, "company" => $_POST['company'], "name" => $_POST['name'], "street" => $_POST['address'], "apt" => $_POST['suite_number'], "city" => $_POST['city'], "state" => $_POST['state'], "zip" => $_POST['zipcode'], "provider" => $_POST['provider'], "practice" => $practice, "preference" => $array, "urgency" => $_POST['urgency']]);
            $last_id = $pdo->lastInsertId();
        }
        $_SESSION['username'] = $_POST['username'];
        $_SESSION['valid'] = true;
        $_SESSION['id'] = $last_id;
        $_SESSION['name'] = $_POST['name'];
        $_SESSION['status'] = 1;
        $_SESSION['company'] = $_POST['company'];
        $_SESSION['provider'] = $_POST['provider'];
        $_SESSION['password'] = $_POST['password'];
        header("Location: home.html");
    }
?>
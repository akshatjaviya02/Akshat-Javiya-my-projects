<?php
    session_start();
    include 'connection.php';
    $data = json_decode(file_get_contents("php://input"), true);
    // get the preference from the json file and create that many "?" for query to check from their.
    // this query will return all the usernames from login where the practice matches with the users selected preferences.
    $arrays3 = join(',', array_fill(0, count($data['preferences']), '?'));
    $query2 = "SELECT username FROM Login WHERE practice IN ($arrays3);";
    $stmt2 = $pdo->prepare($query2);
    $data2 = $data['preferences'];
    $stmt2->execute($data2);
    $results2 = $stmt2->fetchAll();
    $usernames = array();
    // Push it to array since users can select multiple practice preferences from the database
    foreach($results2 as $row) {
        if($row->username != $_SESSION['username']){
            array_push($usernames, $row->username);
        }
    }
    $arrays2 = join(',', array_fill(0, count($usernames), '?'));
    // this query will return all events from the usernames from last query's results and checks if the DATE of the event is greater than the current date.
    $query = "SELECT * FROM Events WHERE username IN ($arrays2) AND Booked=0 AND DATE(start_time) >= CURRENT_DATE();";
    $all_events = array();
    $arrays = array();
    $stmt = $pdo->prepare($query);
    $stmt->execute($usernames);
    $results = $stmt->fetchAll();
    // inserting into arrays for sending it back to javascript.
    foreach($results as $row) {
        $arrays["id"] = $row->id;
        $arrays["company"] = $row->company;
        $arrays["name"] = $row->name;
        $arrays["title"] = $row->title;
        $arrays["start_time"] = $row->start_time;
        $arrays["end_time"] = $row->end_time;
        $arrays["description"] = $row->description; 
        $arrays["food"] = $row->food;
        $arrays["location"] = $row->location;
        array_push($all_events, $arrays);
    }
    if(count($all_events) > 0) {
        echo json_encode($all_events, JSON_PRETTY_PRINT);
    }
    else {
        echo "Error: No events found";
    }
?>
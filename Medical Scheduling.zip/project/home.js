const login_button = document.querySelector(".login");
const sign_up = document.querySelector(".logins");
const nav_links = document.querySelector(".nav_links");
const directions = document.querySelector(".directions");
let database_up = false;
window.onload = function () {
    database()
    row()

};
function row() {
    // seeing if the users has authenticated or not
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "authenication.php", true);
    xhr.onload = function () {
        if(xhr.responseText == "sucess") {
            login_button.remove();
            sign_up.remove();

            const li4 = document.createElement("li");
            const href4 = document.createElement("a");
            href4.setAttribute("href", "view booking.html");
            let t4 = document.createTextNode("View Bookings");
            href4.appendChild(t4);
            li4.appendChild(href4);
            nav_links.insertBefore(li4, directions);

            const li5 = document.createElement("li");
            const href5 = document.createElement("a");
            href5.setAttribute("href", "provider.html");
            let t5 = document.createTextNode("Find Provider");
            href5.appendChild(t5);
            li5.appendChild(href5);
            nav_links.insertBefore(li5, directions);

            const li3 = document.createElement("li");
            const href3 = document.createElement("a");
            href3.setAttribute("href", "schedule.html");
            let t3 = document.createTextNode("Schedule Meeting");
            href3.appendChild(t3);
            li3.appendChild(href3);
            nav_links.insertBefore(li3, directions);

            const li = document.createElement("li");
            const href = document.createElement("a");
            href.setAttribute("href", "edit-profile.html");
            let t = document.createTextNode("Edit Profile");
            href.appendChild(t);
            li.appendChild(href);
            nav_links.appendChild(li);

            const li2 = document.createElement("li");
            const href2 = document.createElement("a");
            href2.setAttribute("href", "inbox.html");
            let t2 = document.createTextNode("Inbox");
            href2.appendChild(t2);
            li2.appendChild(href2);
            nav_links.appendChild(li2);
            
            const li1 = document.createElement("li");
            const href1 = document.createElement("a");
            href1.setAttribute("href", "logout.php");
            let t1 = document.createTextNode("Logout");
            href1.appendChild(t1);
            li1.appendChild(href1);
            nav_links.appendChild(li1);
        }
    };
    xhr.send();
}
function database() {
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "database.php", true);
    xhr.send();
}
<?php
    session_start();
    include 'connection.php';
    $data = json_decode(file_get_contents("php://input"), true);
    // this query will return specific event by its id.
    $query = "SELECT * FROM Events WHERE `id` = :id;";
    $arrays = array();
    $stmt = $pdo->prepare($query);
    $stmt->execute(['id' => $data['id']]);
    $results = $stmt->fetchAll();
    foreach($results as $row) {
        $arrays["id"] = $row->id;
        $arrays["company"] = $row->company;
        $arrays["name"] = $row->name;
        $arrays["title"] = $row->title;
        $arrays["start_time"] = $row->start_time;
        $arrays["end_time"] = $row->end_time;
        $arrays["description"] = $row->description; 
        $arrays["food"] = $row->food;
        $arrays["location"] = $row->location;
    }
    echo json_encode($arrays, JSON_PRETTY_PRINT);
?>
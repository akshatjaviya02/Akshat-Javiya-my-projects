<?php
    session_start();
    include 'connection.php';
    // this query will return events where the ownership of the event is current user
    $query = "SELECT * FROM Events WHERE username = :username AND name = :name";
    $stmt = $pdo->prepare($query);
    $stmt->execute(["username" => $_SESSION['username'], "name" => $_SESSION['name']]);
    $results = $stmt->fetchAll();
    $all_emails = array();
    $arrays = array();
    if (count($results) == 0) {
        echo "Error: No events found";
        exit();
    }
    else {
        foreach($results as $row) {
            $arrays["id"] = $row->id;
            $arrays["username"] = $row->username;
            $arrays["name"] = $row->name;
            $arrays["title"] = $row->title;
            $arrays["start_time"] = $row->start_time;
            $arrays["end_time"] = $row->end_time;
            $arrays["description"] = $row->description;
            $arrays["food"] = $row->food;
            $arrays["location"] = $row->location;
            $arrays["Booked"] = $row->Booked;
            $arrays["booked_username"] = $row->booked_username;
            $arrays["booked_name"] = $row->booked_name;
            array_push($all_emails, $arrays);
        }
    }
    echo json_encode($all_emails, JSON_PRETTY_PRINT);    
?>
const username = document.querySelector('.username');
const password = document.querySelector('.password');
const error = document.querySelector('.error');
function error_checking() {
    // checking if the username and password are not empty.
    if (username == "" || password == "") {
        window.location.reload(true);
    }
}
function error_check() {
    if (document.location.href.indexOf("?") != -1) {
        error.style.setProperty('--hidden', 'visible');
        error.style.setProperty('--none', 'block');
    } 
}
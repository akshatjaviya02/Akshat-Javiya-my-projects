const login_button = document.querySelector(".login");
const sign_up = document.querySelector(".logins");
const nav_links = document.querySelector(".nav_links");
const directions = document.querySelector(".directions");
const options = document.querySelector(".edit");
const usernames = document.querySelector(".insert-new-username");
const passwords = document.querySelector(".insert-new-password");
const emails = document.querySelector(".insert-new-email");
const practices = document.querySelector(".insert-new-practice");
const preference = document.querySelector(".insert-new-preference");
const address = document.querySelector(".insert-new-address");
const urgency = document.querySelector(".insert-new-urgency");
const selects = document.querySelector(".new-practice");
const forms = document.querySelector(".practices");
const body = document.querySelector("body");
const names = document.querySelector(".insert-new-name");
const company = document.querySelector(".insert-new-company");
const provider = document.querySelector(".insert-new-provider");
const information = document.querySelector(".information");
let all_practice;
let all_preferences;
window.onload = function () {
    row()
    get_information();
    both_practice_and_preferences();
};
function get_information() {
    // gets the information about the user from the database
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "get_all_information.php", true);
    xhr.onload = function () { 
        let data = JSON.parse(xhr.responseText);
        generate_html(data);
    };
    xhr.send();
}
function generate_html(data) {
    // this will generate all the information about the user from the database
    let html = `
    <h4> Id: ${data.id} </h4> <br>
    <h4> Username: ${data.username} <h4><br>
    <h4> Email: ${data.email} </h4><br>
    <h4> Name: ${data.name} <h4><br>
    <h4> Company: ${data.company} </h4><br>
    <h4> Street Name: ${data.street} <h4><br>`;
    if (data.apt != null) {
        html += ` <h4>Apt: ${data.apt}</h4><br>`;
    }
    html += `
    <h4> City: ${data.city} <h4><br>
    <h4>Zip code: ${data.zip} </h4><br>
    <h4> State: ${data.state} <h4><br>
    <h4> Provider: ${data.provider} </h4><br>
    <h4> practice: ${data.practice} </h4><br>`;
    let preference = ""
    for (let i = 0; i < data.preference.length; i++) {
        if (i+1 === data.preference.length) {
            preference += data.preference[i];    
        }
        else {
            preference += data.preference[i] + ", ";
        }
    }
    html += `<h4>Preference: ${preference}</h4><br>`;
    if (data.urgency == 0) {
        html += `<h4>Urgency: No </h4><br`;
    }
    else {
        html += `<h4>Urgency: Yes </h4><br>`;
    }
    information.innerHTML = html;
}
function row() {
    //autentication information accessed by php session.
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "authenication.php", true);
    xhr.onload = function () {
        if(xhr.responseText == "sucess") {
            login_button.remove();
            sign_up.remove();

            const li4 = document.createElement("li");
            const href4 = document.createElement("a");
            href4.setAttribute("href", "view booking.html");
            let t4 = document.createTextNode("View Bookings");
            href4.appendChild(t4);
            li4.appendChild(href4);
            nav_links.insertBefore(li4, directions);

            const li5 = document.createElement("li");
            const href5 = document.createElement("a");
            href5.setAttribute("href", "provider.html");
            let t5 = document.createTextNode("Find Provider");
            href5.appendChild(t5);
            li5.appendChild(href5);
            nav_links.insertBefore(li5, directions);

            const li3 = document.createElement("li");
            const href3 = document.createElement("a");
            href3.setAttribute("href", "schedule.html");
            let t3 = document.createTextNode("Schedule Meeting");
            href3.appendChild(t3);
            li3.appendChild(href3);
            nav_links.insertBefore(li3, directions);

            const li = document.createElement("li");
            const href = document.createElement("a");
            href.setAttribute("href", "edit-profile.html");
            let t = document.createTextNode("Edit Profile");
            href.appendChild(t);
            li.appendChild(href);
            nav_links.appendChild(li);

            const li2 = document.createElement("li");
            const href2 = document.createElement("a");
            href2.setAttribute("href", "inbox.html");
            let t2 = document.createTextNode("Inbox");
            href2.appendChild(t2);
            li2.appendChild(href2);
            nav_links.appendChild(li2);
            
            const li1 = document.createElement("li");
            const href1 = document.createElement("a");
            href1.setAttribute("href", "logout.php");
            let t1 = document.createTextNode("Logout");
            href1.appendChild(t1);
            li1.appendChild(href1);
            nav_links.appendChild(li1);
        }
        else {
            window.location.href = "login.html";
        }
    };
    xhr.send();
}

options.addEventListener("change", function (event) {
    // according to the option it will display the input fields. First all are made invisible. So old fields will be hidden.
    usernames.style.setProperty("--hidden", "invisible");
    usernames.style.setProperty("--none", "none");
    passwords.style.setProperty("--hidden", "invisible");
    passwords.style.setProperty("--none", "none");
    emails.style.setProperty("--hidden", "invisible");
    emails.style.setProperty("--none", "none");
    practices.style.setProperty("--hidden", "invisible");
    practices.style.setProperty("--none", "none");
    preference.style.setProperty("--hidden", "invisible");
    preference.style.setProperty("--none", "none");

    address.style.setProperty("--hidden", "invisible");
    address.style.setProperty("--none", "none");
    urgency.style.setProperty("--hidden", "invisible");
    urgency.style.setProperty("--none", "none");
    names.style.setProperty("--hidden", "invisible");
    names.style.setProperty("--none", "none");

    company.style.setProperty("--hidden", "invisible");
    company.style.setProperty("--none", "none");
    provider.style.setProperty("--hidden", "invisible");
    provider.style.setProperty("--none", "none");
    if (options.value === "username") {
        usernames.style.setProperty("--hidden", "visible");
        usernames.style.setProperty("--none", "block");
    }
    else if (options.value === "password") {
        passwords.style.setProperty("--hidden", "visible");
        passwords.style.setProperty("--none", "block");
    }
    else if (options.value === "email") {
        emails.style.setProperty("--hidden", "visible");
        emails.style.setProperty("--none", "block");
    }
    else if (options.value === "practice") {
        practices.style.setProperty("--hidden", "visible");
        practices.style.setProperty("--none", "block");
    }
    else if (options.value === "preferences") {
        preference.style.setProperty("--hidden", "visible");
        preference.style.setProperty("--none", "block");
    }
    else if (options.value === "address") {
        address.style.setProperty("--hidden", "visible");
        address.style.setProperty("--none", "block");
    }
    else if (options.value === "urgency") {
        urgency.style.setProperty("--hidden", "visible");
        urgency.style.setProperty("--none", "block");
    }
    else if (options.value === "name") {
        names.style.setProperty("--hidden", "visible");
        names.style.setProperty("--none", "block");
    }
    else if (options.value === "company") {
        company.style.setProperty("--hidden", "visible");
        company.style.setProperty("--none", "block");
    }
    else if (options.value === "provider") {
        provider.style.setProperty("--hidden", "visible");
        provider.style.setProperty("--none", "block");
    }
    event.preventDefault();
})
function both_practice_and_preferences() {
    // the following function will populate preference and practice input fields 
    let none = new Option("None", "None");
    selects.appendChild(none);
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "drop_down.php", true);
    xhr.onload = function () {
        let data = JSON.parse(xhr.responseText);
        data.map((result) => {
            let name = new Option(result.practice, result.practice);
            selects.appendChild(name, undefined);
        });
        preference_html(data);
    };
    xhr.send();
    let second = new Option('Other', 'Other')
    selects.appendChild(second, undefined)
}
selects.addEventListener("change", function () {
    // if the user intend to insert his own practice then other input will be displayed. 
    const button = document.querySelector('.submit2');
    if (selects.value === 'Other') {
        const input = document.createElement('input');
        input.setAttribute('name', 'other');
        input.setAttribute('id', 'others');
        input.setAttribute('type', 'text');
        input.setAttribute('class', 'other_input');
        input.setAttribute('placeholder', 'other');
        forms.appendChild(input);
        button.style.setProperty('top', '150px');
    }
    else {

        let input = document.getElementById('others');
        if (input != null && selects.value != 'Other') {
            let other = document.getElementById('others');
            forms.removeChild(other);
            button.style.setProperty('top', '90px');
        }
    }
});
function preference_html(data) {
    // prints the preferences in checkbox for selecting multiple and user doesn't have to holddown the ctrl key.
    all_preferences = data
    let preferences_html = `<form action="edit-profile.php" method="POST">`;
    for (let i = 0; i < data.length; i++) { 
        preferences_html += `<input type="checkbox" name="preference[]" class="preference" value="${data[i].practice}"> <label>${data[i].practice}<br></label>`;
    }
    preferences_html += `
            <input type="hidden" name="option" value="preference"></input>
            <button type="submit" class="submit3"> Send </button>
        </form> 
        <button type="button" class="select" onclick="select_all()">Select All</button>
        <button type="button" class="clear" onclick="clear_all()">Clear All</button>`;
        preference.innerHTML = preferences_html;
}
function select_all() {
    // selects all preferences.
    for (let i = 0; i < all_preferences.length; i++) {
        const to_select = document.getElementsByClassName("preference");
        if (to_select[i].type == 'checkbox') {
            to_select[i].checked = true;
        }
    }
}
function clear_all() {
    //clears all preferences
    for (let i = 0; i < all_preferences.length; i++) {
        const to_select = document.getElementsByClassName("preference");
        if (to_select[i].type == 'checkbox') {
            to_select[i].checked = false;
        }
    }
}
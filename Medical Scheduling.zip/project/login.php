<?php
    session_start();
    include 'connection.php';
    // this query will return ID, username, password, company, name, provider because this will be assigned to session array.
    $query_1 = "SELECT ID, username, password, Company, Name, provider FROM Login WHERE username = :username;";
    $stmt = $pdo->prepare($query_1);
    $username = $_POST['usernames'];
    $stmt->execute(['username' => $username]);
    
    $results = $stmt->fetchAll();
    $password = $_POST['passwords'];
    foreach ($results as $row) {
        if(password_verify($password, $row->password)){
            $_SESSION['username'] = $row->username;
            $_SESSION['valid'] = true;
            $_SESSION['name'] = $row->Name;
            $_SESSION['company'] = $row->Company;
            $_SESSION['status'] = 1;
            $_SESSION['provider'] = $row->provider;
            $_SESSION['password'] = $_POST['password'];
            $_SESSION['id'] = $row->ID;
            header("Location: home.html");
            exit();
        }
        else {
            header("Location: login.html?error=invalid");
            exit();

        }
    }
?>
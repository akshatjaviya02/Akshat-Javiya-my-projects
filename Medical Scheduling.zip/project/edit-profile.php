<?php
    session_start();
    include 'connection.php';
    // if the option of the user is username then execute this if part.
    if($_POST['option'] == "username") {
        $query = "UPDATE `Login` SET `username` = :usernames WHERE ID = :id;";
        $stmt = $pdo->prepare($query);
        $stmt->execute(["usernames" => $_POST['username'], "id" => $_SESSION['id']]);
        $_SESSION['username'] = $username;
    }
    else if($_POST['option'] == 'password') {
        // if the option of the user is password then execute this if part.
        $options = [
            'cost' => 12,
        ];
        $hashed_password = password_hash($_POST['password'], PASSWORD_BCRYPT, $options);
        $query = "UPDATE `Login` SET `password` = :password WHERE ID = :id;";
        $stmt = $pdo->prepare($query);
        echo $_SESSION['id']."\n";
        $stmt->execute(['password' => $hashed_password, "id" => $_SESSION['id']]);
        $_SESSION['password'] = $_POST['password'];
    }
    else if($_POST['option'] == 'practice') {
        // if the option of the user is practice then execute this if part.
        $practice = "";
        // check for if the users inserted into other input field.
        if ($_POST['other'] != '') {
            $practice = $_POST['other'];
        }
        else {
            $practice = $_POST['practice'];
        }
        $query = "UPDATE `Login` SET practice = :practice WHERE ID = :id;";
        $stmt = $pdo->prepare($query);
        $stmt->execute(['practice' => $practice, "id" => $_SESSION['id']]);
    }
    else if($_POST['option'] == 'email') {
        // if the option of the user is email then execute this if part.
        $query = "UPDATE `Login` SET email = :email WHERE ID = :id;";
        $stmt = $pdo->prepare($query);
        $stmt->execute([':email' => $_POST['email'], "id" => $_SESSION['id']]);
    }
    else if($_POST['option'] == 'preference') {
        // if the option of the user is preference then execute this if part.
        $array = serialize($_POST['preference']);
        $query = "UPDATE `Login` SET preference = :preference WHERE ID = :id;";
        $stmt = $pdo->prepare($query);
        $stmt->execute(['preference' => $array, "id" => $_SESSION['id']]);
    }
    else if($_POST['option'] == 'address') {
        // if the option of the user is address then execute this if part. And the length of suite number is 0.
        if(strlen($_POST['suite_number']) == 0) {
            $query = "UPDATE `Login` SET `street_name` = :street, `City` = :city, `State` = :state, `zipcode` = :zipcode WHERE ID = :id;";
            $stmt = $pdo->prepare($query);
            $stmt->execute(["street" => $_POST['address'], "city" => $_POST['city'], "state" => $_POST['state'], "zipcode" => $_POST['zipcode'], "id" => $_SESSION['id']]);
        }
        else {
            // else execute this else part with the length of suite number.
            $query = "UPDATE `Login` SET `street_name` = :street, `Apt` = :apt, `City` = :city, `State` = :state, `zipcode` = :zipcode WHERE ID = :id;";
            $stmt = $pdo->prepare($query);
            $stmt->execute(["street" => $_POST['address'], "apt" => $_POST['suite_number'], "city" => $_POST['city'], "state" => $_POST['state'], "zipcode" => $_POST['zipcode'], "id" => $_SESSION['id']]);   
        }
    }
    else if($_POST['option'] == 'urgency') {
        // if the option of the user is urgency then execute this if part.
        $query = "UPDATE `Login` SET urgency = :urgency WHERE ID = :id;";
        $stmt = $pdo->prepare($query);
        $stmt->execute(['urgency' => $_POST['urgency'], "id" => $_SESSION['id']]);
    }
    else if($_POST['option'] == "name") {
        // if the option of the user is name then execute this if part.
        $query = "UPDATE `Login` SET `Name` = :name WHERE ID = :id;";
        $stmt = $pdo->prepare($query);
        $stmt->execute(["name" => $_POST['name'], "id" => $_SESSION['id']]);
        $_SESSION['name'] = $_POST['name'];
    }
    else if($_POST['option'] == 'company') {
        // if the option of the user is company then execute this if part.
        $query = "UPDATE `Login` SET `Company` = :company WHERE ID = :id;";
        $stmt = $pdo->prepare($query);
        $stmt->execute(['company' => $_POST['company'], "id" => $_SESSION['id']]);
        $_SESSION['company'] = $_POST['company'];
    }
    else if($_POST['option'] == 'provider') {
        // if the option of the user is company then execute this if part.
        $query = "UPDATE `Login` SET `provider` = :provider WHERE ID = :id;";
        $stmt = $pdo->prepare($query);
        $stmt->execute(['provider' => $_POST['provider'], "id" => $_SESSION['id']]);
        $_SESSION['provider'] = $_POST['provider'];
    }
    header("Location: edit-profile.html");
?>
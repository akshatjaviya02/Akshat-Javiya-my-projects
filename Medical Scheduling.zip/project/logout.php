<?php
    session_start();
    // removes the variables from the sesion array.
    session_unset();
    // destorys the sesion after unseting the session variables
    session_destroy();
    header("Location: home.html");
?>
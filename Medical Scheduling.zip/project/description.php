<?php
    session_start();
    include 'connection.php';
    $data = json_decode(file_get_contents("php://input"), true);
    // This query will return the owner's username 
    $query = "SELECT `username` FROM `Events` WHERE `id` = :id;";
    $stmt = $pdo->prepare($query);
    $stmt->execute(['id' => $data['id']]);
    $results = $stmt->fetchAll();
    $username = $_SESSION['username'];
    // it will check if the username that query returned is equal to the username in current session. If not, it will return error else return success
    if($results[0]->username != $username) {
        echo "error";
        exit();
    }
    else{
        echo "success";
        exit();
    }
?>
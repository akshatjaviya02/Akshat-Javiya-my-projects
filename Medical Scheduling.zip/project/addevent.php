<?php
    // For users logged in or not logged in
    session_start();
    // connect to database
    include 'connection.php';
    // if the input is not designed to be specific username then use the if statement.
    if(strlen($_POST['username']) == 0) {
        $query = "INSERT INTO `Events` (`username`, `company`, `name`, `title`, `start_time`, `end_time`, `description`, `food`, `location`) VALUES (:username, :company, :name, :title, :start_time, :end_time, :description, :food, :location)";
        $stmt = $pdo->prepare($query);
        $username = $_SESSION['username'];
        $company = $_SESSION['company'];
        $name = $_SESSION['name'];
        $stmt->execute(["username" => $username, "company" => $company, "name" => $name, "title" => $_POST['title'], "start_time" => $_POST['start'], "end_time" => $_POST['end'], "description" => $_POST['description'], "food" => $_POST['food'], "location" => $_POST['location']]);
        if($stmt) {
            header("Location: home.html");
            exit();
        }
        else {
            header("Location: addevent.html?invalid");
            exit();
        }
    } else {
        // find the username input in database to see if the assgined username exists.
        $query1 = "SELECT * FROM `Login` WHERE `username` = :username";
        $stmt = $pdo->prepare($query1);
        $stmt->execute(["username" => $_POST['username']]);
        $results = $stmt->fetchAll();
        // if there no results then the assgined username is invalid
        if(count($results) == 0) {
            header("Location: addevent.html?invalid");
        } 
        else if(count($results) == 1) {
            // if there is only one result then the username is valid.
            $query2 = "INSERT INTO `Events` (`username`, `company`, `name`, `title`, `start_time`, `end_time`, `description`, `food`, `location`, `Booked`, `booked_username`, `booked_name`) VALUES (:username, :company, :name, :title, :start_time, :end_time, :description, :food, :location, :Booked, :booked_username, :booked_name)";
            $stmt2 = $pdo->prepare($query2);
            $username = $_SESSION['username'];
            $company = $_SESSION['company'];
            $name = $_SESSION['name'];
            $stmt2->execute(["username" => $username, "company" => $company, "name" => $name, "title" => $_POST['title'], "start_time" => $_POST['start'], "end_time" => $_POST['end'], "description" => $_POST['description'], "food" => $_POST['food'], "location" => $_POST['location'], "Booked" => 1, "booked_username" => $_POST['username'], "booked_name" => $results[0]->Name]);
            if($stmt2) {
                $query4 = "INSERT INTO `Messages` (sender, sender_name, receiver, receiver_name, subject, message, seen, Important) VALUES (:sender, :sender_name, :receiver, :receiver_name, :subject, :message, :seen, :important);";
                $message = "An event has been confirmed with " . $_SESSION['name'] . " You can view the event details at view booking page.";
                $subject = "Meeting";
                $stmt4 = $pdo->prepare($query4);
                $stmt4->execute(['sender' => $_SESSION['username'], 'sender_name' => $_SESSION['name'], 'receiver' => $results[0]->username, 'receiver_name' => $results[0]->Name, 'subject' => $subject, 'message' => $message, 'seen' => 0, 'important' => 0]);
                if($stmt4) {
                    header("Location: view booking.html");
                    exit();
                }
                else {
                    header("Location: addevent.html?invalid");
                    exit();
                }
            }
            else {
                header("Location: addevent.html?invalid");
                exit();
            }
        }
        else {
            // there are more than one username with same username so we verify correct username with password as they are primary key and hashed password.
            foreach($results as $result) { 
                // if password_verify return true then you insert it into the events table
                if(password_verify($_SESSION['password'], $row->password)) {
                    $query3 = "INSERT INTO `Events` (`username`, `company`, `name`, `title`, `start_time`, `end_time`, `description`, `food`, `location`, `Booked`, `booked_username`, `booked_name`) VALUES (:username, :company, :name, :title, :start_time, :end_time, :description, :food, :location, :Booked, :booked_username, :booked_name)";
                    $stmt3 = $pdo->prepare($query3);
                    $username = $_SESSION['username'];
                    $company = $_SESSION['company'];
                    $name = $_SESSION['name'];
                    $stmt3->execute(["username" => $username, "company" => $company, "name" => $name, "title" => $_POST['title'], "start_time" => $_POST['start'], "end_time" => $_POST['end'], "description" => $_POST['description'], "food" => $_POST['food'], "location" => $_POST['location'], "Booked" => 1, "booked_username" => $row->username, "booked_name" => $row->Name]);
                    if($stmt3) {
                        // if there is not error inserting to events table then you send a message to the assigned user about event confirmation.
                        $query4 = "INSERT INTO `Messages` (sender, sender_name, receiver, receiver_name, subject, message, seen, Important) VALUES (:sender, :sender_name, :receiver, :receiver_name, :subject, :message, :seen, :important);";
                        $message = "An event has been confirmed with " . $_SESSION['name'] . " You can view the event details at view booking page.";
                        $subject = "Meeting";
                        $stmt4 = $pdo->prepare($query4);
                        $stmt4->execute(["sender" => $_SESSION['username'],'sender_name' => $_SESSION['name'], 'receiver' => $row->username, 'receiver_name' => $row->name, 'subject' => $subject, 'message' => $message, 'seen' => 0, 'important' => 0]);
                        // if successful in inserting to messages table then you will be sent to user view_booking page
                        if($stmt4) {
                            header("Location: view booking.html");
                            exit();
                        }
                        else {
                            header("Location: addevent.html?invalid");
                            exit();
                        }
                    }
                    else {
                        header("Location: addevent.html?invalid");
                        exit();
                    }
                }
            }
            header("Location: addevent.html?invalid");
            exit();
        }
    }
?>
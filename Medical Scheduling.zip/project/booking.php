<?php
    session_start();
    include 'connection.php';
    // event id has been passed by json_encode from javascript to php
    $data = json_decode(file_get_contents("php://input"), true);
    $query = "UPDATE Events SET Booked= :book, booked_username = :username, booked_name = :name  WHERE `id` = :id;";
    $stmt = $pdo->prepare($query);
    $stmt->execute(['id' => $data['id'], "username" => $_SESSION['username'], "name" => $_SESSION['name'], "book" => 1]);
    // updates the event table with booked username and name 
    if(!$stmt) {
        echo "error";
        exit();
    }
    else{
        // select the username who created that event 
        $query2 = "SELECT username, name FROM Events WHERE id = :id;";
        $stmt2 = $pdo->prepare($query2);
        $stmt2->execute(['id' => $data['id']]);
        $results = $stmt2->fetchAll();
        // This query will send a update about a reservation has been made to your event.
        $query3 = "INSERT INTO `Messages` (sender, sender_name, receiver, receiver_name, subject, message, seen, Important) VALUES (:sender, :sender_name, :receiver, :receiver_name, :subject, :message, :seen, :important);";
        $message = "A reservation has been placed for the event.";
        $subject = "Meeting";
        $stmt3 = $pdo->prepare($query3);
        $stmt3->execute(['sender' => $_SESSION['username'], 'sender_name' => $_SESSION['name'], 'receiver' => $results[0]->username, 'receiver_name' => $results[0]->name, 'subject' => $subject, 'message' => $message, 'seen' => 0, 'important' => 0]);
        if ($stmt3) {
            echo "success";
            exit();
        }
        else {
            echo "error";
            exit();
        }
    }
?>
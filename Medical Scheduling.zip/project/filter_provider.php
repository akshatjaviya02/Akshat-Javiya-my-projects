<?php
    session_start();
    include 'connection.php';
    $data = json_decode(file_get_contents("php://input"), true);
    $arrays3 = join(',', array_fill(0, count($data['preferences']), '?'));
    if(count($data['preferences']) == 0) { 
        echo "error";
        exit();
    }
    $query = "SELECT zipcode FROM `Login` WHERE username = :username";
    $stmt = $pdo->prepare($query);
    $stmt->execute([":username" => $_SESSION['username']]);
    $results = $stmt->fetchAll();
    $query2 = "SELECT * FROM `Login` WHERE practice IN ($arrays3);";
    $stmt2 = $pdo->prepare($query2);
    $data2 = $data['preferences'];
    $stmt2->execute($data2);
    $results2 = $stmt2->fetchAll();
    $user_zipcode = $results[0]->zipcode;
    $user_provider = $_SESSION['provider']; 
    $all_events = array();
    $arrays = array();
    if (count($results2) == 0) { 
        $arrays["user_provider"] = $user_provider;
        array_push($all_events, $arrays);
        echo json_encode($all_events, JSON_PRETTY_PRINT);
        exit();
    }
    else {
        foreach($results2 as $row) {
            if($row->username != $_SESSION['username']){
                $arrays["id"] = $row->ID;
                $arrays['username'] = $row->username;
                $arrays["company"] = $row->Company;
                $arrays["name"] = $row->Name;
                $arrays['practice'] = $row->practice;
                $arrays['provider'] = $row->provider;
                $arrays["zipcode"] = $row->zipcode;
                $arrays["urgency"] = $row->urgency;
                $arrays["user_zipcode"] = $user_zipcode;
                $arrays["user_provider"] = $user_provider;
                array_push($all_events, $arrays);
                
            }
        }
        echo json_encode($all_events, JSON_PRETTY_PRINT);

    }
?>
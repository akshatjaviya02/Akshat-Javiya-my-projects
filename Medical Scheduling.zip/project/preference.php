<?php
    session_start();
    include 'connection.php';
    // this query will return the prefernece for that current user
    $query = "SELECT preference FROM Login WHERE username = :username;";
    $stmt = $pdo->prepare($query);
    $stmt->execute(["username" => $_SESSION['username']]);
    $results = $stmt->fetchAll();
    if (count($results) == 0) {
        echo "Error: No preference chosen.";
        exit();
    }
    else {
        $result = unserialize($results[0]->preference);
        echo json_encode($result, JSON_PRETTY_PRINT);
        exit();
    }
?>
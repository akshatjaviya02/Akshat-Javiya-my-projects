<?php
    session_start();
    include 'connection.php';
    $data = json_decode(file_get_contents("php://input"), true);
    // this query will remove the event from the table by its id.
    $query = "DELETE FROM Events WHERE id = :id";
    $stmt = $pdo->prepare($query);
    $stmt->execute(['id' => $data['id']]);
    if ($stmt) {
        echo "Success";
        exit();
    }
    else {
        echo "Error";
        exit();
    }
?>
<?php
    session_start();
    include 'connection.php';
    $data = json_decode(file_get_contents("php://input"), true);
    // this query will return replies that are detigated to the message id.
    $query = "SELECT * FROM Replies WHERE message_id = :id ORDER BY sent_date DESC;";
    $stmt = $pdo->prepare($query);
    $stmt->execute(["id" => $data['id']]);
    $all_emails = array();
    $arrays = array();
    $results = $stmt->fetchAll();
    // if there is not replies it will return no replies.
    if (count($results) == 0) {
        echo "error: no replies for this message";
        exit();
    }
    else {
        foreach($results as $row) {
            $arrays["id"] = $row->message_id;
            $arrays["reciever"] = $row->sender;
            $arrays["message"] = $row->message;
            $arrays["sent_time"] = $row->sent_date;
            array_push($all_emails, $arrays);
        }
    }
    echo json_encode($all_emails, JSON_PRETTY_PRINT);
?>
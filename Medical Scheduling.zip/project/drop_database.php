<?php
    // this file will drop database from mysql server.
    $host =  'localhost';
    $user = 'root';
    $password = '';

    $dsn = 'mysql:host='. $host;

    $pdo = new PDO($dsn, $user, $password);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    $sql_use_database = 'DROP DATABASE AkshatProject;';
    $stmt = $pdo->prepare($sql_use_database);
    $stmt->execute();
?>
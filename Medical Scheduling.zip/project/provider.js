
const login_button = document.querySelector(".login");
const sign_up = document.querySelector(".logins");
const nav_links = document.querySelector(".nav_links");
const directions = document.querySelector(".directions");
const body2 = document.querySelector(".body2");
const preference = document.querySelector(".choosing_preference");
const filters2 = document.querySelector(".filter2");
const go_back = document.querySelector(".go_back");
const error = document.querySelector('.error');
let selected_preference;
let list_all_providers;
let preference_data;
let new_id;
window.onload = function () {
    row();
    preferences();
}
function preferences_selected() {
    // this function will get the values selected by user on preference.
    let values = new Array;
    const selected = document.getElementsByName("preference")
    for (let i = 0; i < selected.length; i++) {
        if (selected[i].checked) {
            values.push(selected[i].value);
        }
    }
    selected_preference = values;
    filter_providers()
}


function filter_providers() {
    //this function will get the users according to preference passed.
    body2.style.setProperty("--hidden", "visible");
    body2.style.setProperty("--none", "block");
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "filter_provider.php", true);
    xhr.onload = function () {
        if(xhr.responseText === "error") {
            body2.style.setProperty("--hidden", "invisible");
            body2.style.setProperty("--none", "none");
            error.style.setProperty('--hidden', 'visible');
            error.style.setProperty('--none', 'block');
        }
        else {
            error.style.setProperty('--hidden', 'invisible');
            error.style.setProperty('--none', 'none');
            let data = JSON.parse(xhr.responseText);
            list_all_providers = data;
    
            filter_by_preference_providers_without_data();
        }
    }
    xhr.send(JSON.stringify({ preferences: selected_preference }));
}

function filter_by_preference_providers_without_data() {
    // this function displays the providers by preference
    filters2.style.setProperty("--hidden", "visible");
    filters2.style.setProperty("--none", "block");
    preference.style.setProperty("--hidden", "invisible");
    preference.style.setProperty("--none", "none");
    go_back.style.setProperty("--hidden", "invisible");
    go_back.style.setProperty("--none", "none");
    let provider_html = "";
    let service_html = "";
    if (list_all_providers[0].user_provider === "Doctor") {
        service_html = `<div class="services"><label class="service">Service Provider: </label><br>`;
        provider_html = `<div class="doctors" style="top: 50px;"><label class="doctor">Doctors: </label><br>`;
    }
    else {
        service_html = `<div class="doctors"><label class="doctor"> Doctor: </label><br>`;
        provider_html = `<div class="services" style="top: 50px;"><label class="service">Service Provider: </label><br>`;
    }
    for (let j = 0; j < selected_preference.length; j++) {
        for (let i = 0; i < list_all_providers.length; i++) {
            if (list_all_providers[i].practice == selected_preference[j] && list_all_providers[i].provider != list_all_providers[i].user_provider) {
                service_html += `<a class="description" href="Javascript:void(0)" onclick="display_provider(${list_all_providers[i].id})"><label>${list_all_providers[i].username}</label><label>${list_all_providers[i].name}</label><label>${list_all_providers[i].company}</label><label>${list_all_providers[i].practice}</label><label>${list_all_providers[i].zipcode}</label></a><br>`;

            } else if (list_all_providers[i].practice == selected_preference[j] && list_all_providers[i].provider == list_all_providers[i].user_provider) {
                provider_html += `<a class="description2" href="Javascript:void(0)" onclick="display_provider(${list_all_providers[i].id})"><label>${list_all_providers[i].username}</label><label>${list_all_providers[i].name}</label><label>${list_all_providers[i].company}</label><label>${list_all_providers[i].practice}</label><label>${list_all_providers[i].zipcode}</label></a><br>`;
            }

        }
    }
    if (service_html == `<div class="services"><label class="service">Service Provider: </label><br>` ) {
        service_html += `<p> No service providers are selected as preference.</p>`
    }
    else if (service_html == `<div class="doctors"><label class="doctor"> Doctor: </label><br>`) {
        service_html += `<p> No Doctors are selected as preference.</p>`
    }
    if (provider_html == `<div class="services" style="top: 50px;"><label class="service">Service Provider: </label><br>` ) {
        provider_html += `<p> No service providers selected as preference.</p>`
    }
    else if (provider_html == `<div class="doctors" style="top: 50px;"><label class="doctor">Doctors: </label><br>`) {
        provider_html += `<p> No Doctors selected as preference.</p>`
    }
    service_html += "</div>";
    provider_html += "</div>";
    body2.innerHTML = service_html + provider_html;
}
function display_preference(data) {
    // display preference for users to select.
    let html = "";
    preference_data = data;
    preference.style.setProperty("--hidden", "visible");
    preference.style.setProperty("--none", "block");
    for (let i = 0; i < preference_data.length; i++) {
        html += `<input type="checkbox" name="preference" value="${preference_data[i]}"> <label>${preference_data[i]}<br></label>`;
    }
    html += `<button type="submit" class="select" onclick="select_all()">Select All</button>
    <button type="submit" class="clear" onclick="clear_all()">Clear All</button>
    <button type="submit" class="submit" onclick="preferences_selected()">Next</button>`;
    preference.innerHTML = html;
}
filters2.addEventListener("change", function () {
    // according to input changes the function calls will change.
    if (filters2.value == "location") {
        filter_by_location_providers();
    }
    else if (filters2.value == "urgency") {
        filter_by_urgency_providers();
    }
    else {
        filter_by_preference_providers_without_data();
    }
})
function display_provider(id) {
    // this function displays the selected provider.
    new_id = id;
    preference.style.setProperty("--hidden", "invisible");
    preference.style.setProperty("--none", 'none');
    filters2.style.setProperty("--hidden", "invisible");
    filters2.style.setProperty("--none", "none");
    body2.style.setProperty("--hidden", "visible");
    body2.style.setProperty("--none", "block");
    go_back.style.setProperty("--hidden", "visible");
    go_back.style.setProperty("--none", "block");
    let result = list_all_providers.find(({ id }) => id == new_id);
    let url = "inbox.html?username=" + encodeURIComponent(result.username);
    let html = `
    <h3 class="sender">Usernane: ${result.username}</h3>
        <h3 class="sender_name">Name: ${result.name} </h3> 
        <h3 class="sent_time">Practice: ${result.practice}</h3> 
        <h3 class="subjects">Company: ${result.company}</h3>
        <a class="inbox_page" href="${url}"><button class="inbox">Eamil</button></a>`;
    body2.innerHTML = html;
}
function filter_by_location_providers() {
    // this function displays the providers by location
    filters2.style.setProperty("--hidden", "visible");
    filters2.style.setProperty("--none", "block");
    go_back.style.setProperty("--hidden", "invisible");
    go_back.style.setProperty("--none", "none");
    let provider_html = "";
    let service_html = "";
    // alternate according to user's provider
    if (list_all_providers[0].user_provider === "Doctor") {
        service_html = `<div class="services"><label class="service">Service Provider: </label><br>`;
        provider_html = `<div class="doctors" style="top: 50px;"><label class="doctor">Doctors: </label><br>`;
    }
    else {
        service_html = `<div class="doctors"><label class="doctor"> Doctor: </label><br>`;
        provider_html = `<div class="services" style="top: 50px;"><label class="service">Service Provider: </label><br>`;
    }
    for (let i = 0; i < list_all_providers.length; i++) {
        if (list_all_providers[i].zipcode == list_all_providers[i].user_zipcode && list_all_providers[i].provider != list_all_providers[i].user_provider) {
            if (list_all_providers[i].zipcode == undefined || list_all_providers[i].user_zipcode == undefined || list_all_providers[i].provider == undefined) {
                continue;
            }
            service_html += `<a class="description" href="Javascript:void(0)" onclick="display_provider(${list_all_providers[i].id})"><label>${list_all_providers[i].username}</label><label>${list_all_providers[i].name}</label><label>${list_all_providers[i].company}</label><label>${list_all_providers[i].practice}</label><label>${list_all_providers[i].zipcode}</label></a><br>`;
        }
        else if (list_all_providers[i].zipcode == list_all_providers[i].user_zipcode && list_all_providers[i].provider == list_all_providers[i].user_provider) {
            provider_html += `<a class="description" href="Javascript:void(0) onclick="display_provider(${list_all_providers[i].id})""><label>${list_all_providers[i].username}</label><label>${list_all_providers[i].name}</label><label>${list_all_providers[i].company}</label><label>${list_all_providers[i].practice}</label><label>${list_all_providers[i].zipcode}</label></a><br>`;
        }
    }
    // check for empty provider
    if (service_html == `<div class="services"><label class="service">Service Provider: </label><br>` ) {
        service_html += `<p> No service providers are nearby you.</p>`
    }
    else if (service_html == `<div class="doctors"><label class="doctor"> Doctor: </label><br>`) {
        service_html += `<p> No Doctors are nearby you.</p>`
    }
    if (provider_html == `<div class="services" style="top: 50px;"><label class="service">Service Provider: </label><br>` ) {
        provider_html += `<p> No service providers are nearby you.</p>`
    }
    else if (provider_html == `<div class="doctors" style="top: 50px;"><label class="doctor">Doctors: </label><br>`) {
        provider_html += `<p> No Doctors are nearby you.</p>`
    }
    service_html += "</div>";
    provider_html += "</div>";
    body2.innerHTML = service_html + provider_html;
}
function filter_by_urgency_providers() {
    // this function displays the providers by urgency
    filters2.style.setProperty("--hidden", "visible");
    filters2.style.setProperty("--none", "block");
    go_back.style.setProperty("--hidden", "invisible");
    go_back.style.setProperty("--none", "none");
    let provider_html = "";
    let service_html = "";
    if (list_all_providers[0].user_provider === "Doctor") {
        service_html = `<div class="services"><label class="service">Service Provider: </label><br>`;
        provider_html = `<div class="doctors" style="top: 50px;"><label class="doctor">Doctors: </label><br>`;
    }
    else {
        service_html = `<div class="doctors"><label class="doctor"> Doctor: </label><br>`;
        provider_html = `<div class="services" style="top: 50px;"><label class="service">Service Provider: </label><br>`;
    }
    for (let i = 0; i < list_all_providers.length; i++) {
        if (list_all_providers[i].urgency == 1 && list_all_providers[i].provider != list_all_providers[i].user_provider) {
            service_html += `<a class="description" href="Javascript:void(0)" onclick="display_provider(${list_all_providers[i].id})"><label>${list_all_providers[i].username}</label><label>${list_all_providers[i].name}</label><label>${list_all_providers[i].company}</label><label>${list_all_providers[i].practice}</label><label>${list_all_providers[i].zipcode}</label></a><br>`;
        }
        else if (list_all_providers[i].urgency == 1 && list_all_providers[i].provider == list_all_providers[i].user_provider) {
            provider_html += `<a class="description" href="Javascript:void(0) onclick="display_provider(${list_all_providers[i].id})""><label>${list_all_providers[i].username}</label><label>${list_all_providers[i].name}</label><label>${list_all_providers[i].company}</label><label>${list_all_providers[i].practice}</label><label>${list_all_providers[i].zipcode}</label></a><br>`;
        }
    }
    if (service_html == `<div class="services"><label class="service">Service Provider: </label><br>` ) {
        service_html += `<p> No service providers are in urgency list.</p>`
    }
    else if (service_html == `<div class="doctors"><label class="doctor"> Doctor: </label><br>`) {
        service_html += `<p> No Doctors are in urgency list.</p>`
    }
    if (provider_html == `<div class="doctors" style="top: 50px;"><label class="doctor">Doctors: </label><br>` ) {
        provider_html += `<p> No service providers are in urgency list.</p>`
    }
    else if (provider_html == `<div class="services" style="top: 50px;"><label class="service">Service Provider: </label><br>`) {
        provider_html += `<p> No Doctors are in urgency list.</p>`
    }
    service_html += "</div>";
    provider_html += "</div>";
    body2.innerHTML = service_html + provider_html;
}
function preferences() {
    // this function gets the user preferences from database
    filters2.style.setProperty("--hidden", "invisible");
    filters2.style.setProperty("--none", "none");
    go_back.style.setProperty("--hidden", "invisible");
    go_back.style.setProperty("--none", "none");
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "preference.php", true);
    xhr.onload = function () {
        if (xhr.responseText == "Error: No preference chosen.") {
            console.log(xhr.responseText);
        }
        else {
            let data = JSON.parse(xhr.responseText);
            display_preference(data)
        }

    }
    xhr.send();
}
function display_preference(data) {
    // this function displays the preference to the html page.
    filters2.style.setProperty("--hidden", "invisible");
    filters2.style.setProperty("--none", "none");
    go_back.style.setProperty("--hidden", "invisible");
    go_back.style.setProperty("--none", "none");
    let html = "";
    preference_data = data;
    preference.style.setProperty("--hidden", "visible");
    preference.style.setProperty("--none", "block");
    for (let i = 0; i < preference_data.length; i++) {
        html += `<input type="checkbox" name="preference" value="${preference_data[i]}"> <label>${preference_data[i]}<br></label>`;
    }
    html += `<button type="submit" class="select" onclick="select_all()">Select All</button>
    <button type="submit" class="clear" onclick="clear_all()">Clear All</button>
    <button type="submit" class="submit" onclick="preferences_selected()">Next</button>`;
    preference.innerHTML = html;
}
function select_all() {
    // This function selects all preferences
    for (let i = 0; i < preference_data.length; i++) {
        const to_select = document.getElementsByName("preference");
        if (to_select[i].type == 'checkbox') {
            to_select[i].checked = true;
        }
    }
}
function clear_all() {
    // This function clears all preferences
    for (let i = 0; i < preference_data.length; i++) {
        const to_select = document.getElementsByName("preference");
        if (to_select[i].type == 'checkbox') {
            to_select[i].checked = false;
        }
    }
}

function row() {
    // this function is for authenication verification.
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "authenication.php", true);
    xhr.onload = function () {
        if (xhr.responseText == "sucess") {
            login_button.remove();
            sign_up.remove();

            const li4 = document.createElement("li");
            const href4 = document.createElement("a");
            href4.setAttribute("href", "view booking.html");
            let t4 = document.createTextNode("View Bookings");
            href4.appendChild(t4);
            li4.appendChild(href4);
            nav_links.insertBefore(li4, directions);

            const li5 = document.createElement("li");
            const href5 = document.createElement("a");
            href5.setAttribute("href", "provider.html");
            let t5 = document.createTextNode("Find Provider");
            href5.appendChild(t5);
            li5.appendChild(href5);
            nav_links.insertBefore(li5, directions);

            const li3 = document.createElement("li");
            const href3 = document.createElement("a");
            href3.setAttribute("href", "schedule.html");
            let t3 = document.createTextNode("Schedule Meeting");
            href3.appendChild(t3);
            li3.appendChild(href3);
            nav_links.insertBefore(li3, directions);

            const li = document.createElement("li");
            const href = document.createElement("a");
            href.setAttribute("href", "edit-profile.html");
            let t = document.createTextNode("Edit Profile");
            href.appendChild(t);
            li.appendChild(href);
            nav_links.appendChild(li);

            const li2 = document.createElement("li");
            const href2 = document.createElement("a");
            href2.setAttribute("href", "inbox.html");
            let t2 = document.createTextNode("Inbox");
            href2.appendChild(t2);
            li2.appendChild(href2);
            nav_links.appendChild(li2);

            const li1 = document.createElement("li");
            const href1 = document.createElement("a");
            href1.setAttribute("href", "logout.php");
            let t1 = document.createTextNode("Logout");
            href1.appendChild(t1);
            li1.appendChild(href1);
            nav_links.appendChild(li1);
        }
        else {
            window.location.href = "login.html";
        }
    };
    xhr.send();
}

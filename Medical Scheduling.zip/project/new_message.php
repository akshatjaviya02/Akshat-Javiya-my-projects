<?php
    session_start();
    include 'connection.php';
    // this query will return name of the user by its username
    $query = "SELECT name FROM Login WHERE username = :username;";
    $stmt = $pdo->prepare($query);
    $stmt->execute(["username" => $_POST['username']]);
    $results = $stmt->fetchAll();
    // this query will create a row in messages table about the current user sending a message to that user.
    $query3 = "INSERT INTO `Messages` (`sender`, `sender_name`, `receiver`, `receiver_name`, `subject`, `message`, `seen`, `Important`) VALUES (:sender, :sender_name, :receiver, :receiver_name, :subject, :message, :seen, :important);";
    $stmt3 = $pdo->prepare($query3);
    $stmt3->execute(['sender' => $_SESSION['username'], 'sender_name' => $_SESSION['name'], 'receiver' => $_POST["username"], 'receiver_name' => $results[0]->name, 'subject' => $_POST['subject'], 'message' => $_POST['message'], 'seen' => 0, 'important' => 0]);
    if ($stmt3) {
        echo "success";
        header("Location: inbox.html");
    }
    else {
        echo "error";
        header("Location: inbox.html");
    }
?>
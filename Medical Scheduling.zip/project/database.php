<?php
    // connect to the mysql server
    $host =  'localhost';
    $user = 'root';
    $password = '';

    $dsn = 'mysql:host='. $host;

    $pdo = new PDO($dsn, $user, $password);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    // try if there is Database 
    try {
        $sql_use_database = "USE AkshatProject;";
        $stmt = $pdo->prepare($sql_use_database);
        $stmt->execute();
        echo "Database exits";
        exit();

    } catch(PDOException $e) {
        // if not then create a new database and populate it with the information
        $sql_create_database = "CREATE DATABASE AkshatProject;";
        $stmt = $pdo->prepare($sql_create_database);
        $stmt->execute();
        $sql_use_database = 'USE AkshatProject;';
        $stmt1 = $pdo->prepare($sql_use_database);
        $stmt1->execute();
        // tables creation 
        $sql_login = "CREATE TABLE `Login` (
            `ID` int(11) NOT NULL PRIMARY KEY,
            `username` varchar(25) NOT NULL,
            `email` varchar(45) NOT NULL,
            `password` varchar(60) NOT NULL,
            `Name` varchar(45) NOT NULL,
            `Company` varchar(45) NOT NULL,
            `street_name` varchar(60) NOT NULL,
            `Apt` varchar(10) DEFAULT NULL,
            `City` varchar(45) NOT NULL,
            `State` char(2) NOT NULL,
            `zipcode` char(5) NOT NULL,
            `provider` varchar(25) NOT NULL,
            `practice` varchar(45) NOT NULL,
            `preference` mediumtext NOT NULL,
            `urgency` tinyint(1) NOT NULL DEFAULT 0
          ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
        $stmt2 = $pdo->prepare($sql_login);
        $stmt2->execute();
        // values are intered to login table
        $sql_insert_values_login = "INSERT INTO `Login` (`ID`, `username`, `email`, `password`, `Name`, `Company`, `street_name`, `Apt`, `City`, `State`, `zipcode`, `provider`, `practice`, `preference`, `urgency`) VALUES
        (1, 'test', 'test@gmail.com', '$2y$12$4QBUf5RqLUaQVPYuphoqQuFYGI0MZzhe0u.3Oqe37TPYlLnPtauLy', 'Test', 'Test Doctor', '800 N State College Blvd', '16', 'Fullerton', 'CA', '92833', 'Doctor', 'Doctor(family doctor)', 'a:3:{i:0;s:6:\"Doctor\";i:1;s:13:\"Heart Surgeon\";i:2;s:16:\"Lungs Specialist\";}', 1),
        (2, 'student', 'student@gmail.com',   '$2y$12$20vubhfHuBwzZJv4J8004e6CU39ib.4EconiNxg/YWOr4ptF0HL3i', 'Student', 'Student Doctor', '800 N State College Blvd', '19', 'Fullerton', 'CA', '92833', 'Doctor', 'Doctor(family doctor)', 'a:1:{i:0;s:15:\"gloves Provider\";}', 1),
        (3, 'student2', 'student2@icloud.com', '$2y$12$9VrvYBdL.tgNFJ1dk1L5xOi2iCxhHVf7Zipa9NE7Q.hK.4YY8b/XC', 'Student2', 'Student2 Doctor', '800 N State Blvd', NULL, 'Anaheim', 'CA', '38475', 'Doctor', 'Heart Surgeon', 'a:1:{i:0;s:6:\"Doctor\";}', 1),
        (4, 'student3', 'student3@gmail.com', '$2y$12$3J6ClVelY3O.3fqd7rCnL.ft6nhLdqT84LUaMBG9s7aMycTS0.fGS', 'Student3', 'Student3 Doctor', '802 N state College Blvd', NULL, 'Yorba Linda', 'CA', '98465', 'Doctor', 'Lungs Specialist', 'a:3:{i:0;s:6:\"Doctor\";i:1;s:9:\"Pharamacy\";i:2;s:13:\"Heart Surgeon\";}', 0),
        (5, 'student4', 'student4@gmail.com', '$2y$12$66SXCBhxQ13Fb58GpCsJyOSsXjjXIEO1Q/w06oFtSpc.gEcFRt1iO', 'Student4', 'Student4 gloves ', '800 N Gilbert St', 'Suite 16', 'Fullerton', 'CA', '92833', 'Service Provider', 'gloves Provider', 'a:3:{i:0;s:6:\"Doctor\";i:1;s:13:\"Heart Surgeon\";i:2;s:16:\"Lungs Specialist\";}', 1),
        (6, 'student5', 'student5@gmail.com', '$2y$12$7SXx3AGSnwfwLoTJSQTAdOTWqpUoeXEQK8J4bKHcgzheuFzJCPasa', 'Student5', 'student5 gloves', '800 N State College Blvd', NULL, 'Santa Ana', 'CA', '68155', 'Service Provider', 'gloves Provider', 'a:3:{i:0;s:6:\"Doctor\";i:1;s:13:\"Heart Surgeon\";i:2;s:16:\"Lungs Specialist\";}', 0),
        (7, 'student6', 'student6@gmail.com', '$2y$12$6gM2uORGXhx0kT/z97.P1usm/uezZmHmnn9KAJ2OCI67fui7Xbt1e', 'Student6', 'Student6 gloves', '800 N State College Blvd', NULL, 'San Diego', 'CA', '46468', 'Service Provider', 'gloves Provider', 'a:3:{i:0;s:6:\"Doctor\";i:1;s:13:\"Heart Surgeon\";i:2;s:16:\"Lungs Specialist\";}', 1);";
        $stmt2 = $pdo->prepare($sql_insert_values_login);
        $stmt2->execute();
        
        // events table will be created 
        $sql_events = "CREATE TABLE `Events` (
            `id` int(11) NOT NULL PRIMARY KEY,
            `username` varchar(25) NOT NULL,
            `company` varchar(45) NOT NULL,
            `name` varchar(45) NOT NULL,
            `title` varchar(25) NOT NULL,
            `start_time` datetime NOT NULL,
            `end_time` datetime NOT NULL,
            `description` text NOT NULL,
            `food` text NOT NULL,
            `location` tinytext NOT NULL,
            `Booked` tinyint(1) NOT NULL DEFAULT 0,
            `booked_username` varchar(25) DEFAULT NULL,
            `booked_name` varchar(45) DEFAULT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
        $stmt3 = $pdo->prepare($sql_events);
        $stmt3->execute();
 
        // values would be inserted to events table
        $sql_insert_values_events = "INSERT INTO `Events` (`id`, `username`, `company`, `name`, `title`, `start_time`, `end_time`, `description`, `food`, `location`, `Booked`, `booked_username`, `booked_name`) VALUES
        (5, 'student2', 'Student2 Doctor', 'djfghdsjf', 'jofjsdj', '2023-05-08 12:00:00', '2023-05-08 13:00:00', 'wiefjwfjewoijf', 'isdgjigj', 'fkjbdijvid', 0, NULL, NULL),
        (19, 'student', 'Student Doctor', 'Student', 'Meeting', '2023-05-18 13:00:00', '2023-05-18 15:00:00', 'nvjdvnwdijvwfjwfjdj', 'dsvujdsvsdjio', 'ijvjdfijvsdjvodjv', 0, NULL, NULL),
        (20, 'student', 'Student Doctor', 'Student', 'ijfgioefjvif', '2023-05-22 17:00:00', '2023-05-22 18:00:00', 'ifvhjefveiuvjeu', 'dfvjeoivjdofibj', 'oifjvbifdjbofij', 0, NULL, NULL),
        (21, 'student', 'Student Doctor', 'Student', 'fjvdofkmbok', '2023-05-23 20:00:00', '2023-05-23 21:00:00', 'uvhweuvhwuihvudhv', 'whwiuvhwudh', 'sduvhsdhvsjd', 0, NULL, NULL),
        (22, 'student', 'Student Doctor', 'Student', 'djfbkfdjv', '2023-05-20 08:10:00', '2023-05-20 09:00:00', 'fvmsokdvmokwdm1', 'fkjvdfivkkdf m', 'fdvkspdokvspdokv', 0, NULL, NULL),
        (23, 'student2', 'Student2 Doctor', 'Student2', 'sdjfhsdkj', '2024-05-24 17:00:00', '2024-05-24 18:00:00', 'fgijdflghfdjgh', 'sdjfdijgdfi', 'dfkjgdfkjdfk', 0, NULL, NULL),
        (24, 'student2', 'Student2 Doctor', 'Student2', 'kdgjdfj', '2024-05-25 17:00:00', '2024-05-25 18:00:00', 'fdkjgdflkgj', 'fdjdfklgjdk', 'dfkjgdfkljg', 0, NULL, NULL),
        (25, 'student4', 'Student4 gloves', 'Student4', 'dsfjdsklgj', '2024-05-26 18:00:00', '2024-05-26 19:00:00', 'sjfsdj', 'djfsdlfjkd', 'dkfjsdlkfj', 1, 'student', 'Student'),
        (26, 'student4', 'Student4 gloves', 'Student4', 'dsfjdsklgj', '2024-05-28 18:00:00', '2024-05-28 19:00:00', 'sjfsdj', 'djfsdlfjkd', 'dkfjsdlkfj', 0, NULL, NULL),
        (27, 'student2', 'Student2 Doctor', 'Student2', 'dsfjdsklgj', '2024-05-26 18:00:00', '2024-05-26 19:00:00', 'sjfsdj', 'djfsdlfjkd', 'dkfjsdlkfj', 0, NULL, NULL),
        (28, 'student2', 'Student2 Doctor', 'Student2', 'dsfjdsklgj', '2024-05-26 18:00:00', '2024-05-26 19:00:00', 'sjfsdj', 'djfsdlfjkd', 'dkfjsdlkfj', 0, NULL, NULL),
        (29, 'student2', 'Student2 Doctor', 'Student2', 'dsfjdsklgj', '2024-05-26 18:00:00', '2024-05-26 19:00:00', 'sjfsdj', 'djfsdlfjkd', 'dkfjsdlkfj', 0, NULL, NULL),
        (30, 'student2', 'Student2 Doctor', 'Student2', 'dsfjdsklgj', '2024-05-26 18:00:00', '2024-05-26 19:00:00', 'sjfsdj', 'djfsdlfjkd', 'dkfjsdlkfj', 0, NULL, NULL),
        (32, 'student', 'Student Doctor', 'Student', 'sfijsdij', '2023-06-05 17:00:00', '2023-06-05 18:00:00', 'skdfjsdlfk', 'dkfjvkdfvkl', 'd;vldfkvdfl\'k', 0, NULL, NULL);";
        $stmt4 = $pdo->prepare($sql_insert_values_events);
        $stmt4->execute();
        
        // creation of messages table 
        $sql_messages = "CREATE TABLE `Messages` (
            `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `sender` varchar(25) NOT NULL,
            `sender_name` varchar(45) NOT NULL,
            `receiver` varchar(25) NOT NULL,
            `receiver_name` varchar(45) NOT NULL,
            `subject` varchar(45) NOT NULL,
            `message` text NOT NULL,
            `seen` tinyint(1) NOT NULL DEFAULT 0,
            `sent_time` datetime NOT NULL DEFAULT current_timestamp(),
            `Important` tinyint(1) NOT NULL DEFAULT 0
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
        $stmt5 = $pdo->prepare($sql_messages);
        $stmt5->execute();
 
        // values inserted into messages table
        $sql_insert_values_messages = "INSERT INTO `Messages` (`id`, `sender`, `sender_name`, `receiver`, `receiver_name`, `subject`, `message`, `seen`, `sent_time`, `Important`) VALUES
        (1, 'student2', 'Student2', 'student', 'Student', 'Meeting', 'A reservation has been placed for the event.', 0, '2023-04-09 10:30:41', 1),
        (2, 'student2', 'Student2', 'student', 'Student', 'Meeting', 'A reservation has been placed for the event.', 0, '2023-04-09 10:31:03', 1),
        (3, 'student', 'Student', 'student2', 'Student2', 'Meeting', 'Hello,\r\nI would be happy to see you.\r\n\r\nSincerely,\r\nStudent', 1, '2023-04-09 18:28:59', 0),
        (5, 'student', 'Student', 'student2', 'Student2', 'sdhsdhgf', 'sduhfghjfshfbfshdfbwe ', 0, '2023-04-09 20:56:20', 0),
        (6, 'student4', 'Student4', 'student2', 'Student2', 'sdhsdhgf', 'sduhfghjfshfbfshdfbwe ', 1, '2023-04-09 20:58:45', 0),
        (7, 'student', 'Student', 'student2', 'Student2', 'sdhsdhgf', 'sduhfghjfshfbfshdfbwe ', 1, '2023-04-09 20:59:44', 0),
        (8, 'student2', 'Student2', 'test', 'Test', 'Meeting', 'A reservation has been placed for the event.', 0, '2023-04-11 15:42:06', 0),
        (9, 'student2', 'Student2', 'student', 'Student', 'Meeting', 'A reservation has been placed for the event.', 0, '2023-04-11 15:48:54', 1),
        (10, 'student2', 'Student2', 'student', 'Student', 'Meeting', 'A reservation has been placed for the event.', 1, '2023-04-11 15:49:45', 0),
        (11, 'student2', 'Student2', 'student', 'Student', 'Removed Booking by Student2', 'Reservation has been removed by Student2 .', 1, '2023-04-17 15:09:50', 0),
        (12, 'student2', 'Student2', 'test', 'Test', 'sjghsjd', 'jdfghdfkjghdj ', 0, '2023-04-21 10:36:04', 0),
        (13, 'student2', 'Student2', 'test', 'Test', 'Meeting', 'An event has been confirmed with Student2 You can view the event details at view booking page.', 0, '2023-04-23 19:48:51', 0),
        (14, 'test', 'Test', 'student2', 'Student2', 'Removed Booking by Test', 'Reservation has been removed by Test.', 0, '2023-04-24 16:34:56', 0),
        (15, 'test', 'Test', 'student2', 'Student2', 'Removed Booking by Test', 'Reservation has been removed by Test.', 0, '2023-04-24 16:35:57', 0),
        (16, 'test', 'Test', 'student2', 'Student2', 'Removed Booking by Test', 'Reservation has been removed by Test.', 0, '2023-04-24 16:41:15', 0),
        (17, 'test', 'Test', 'student2', 'Student2', 'Removed Booking by Test', 'Reservation has been removed by Test.', 0, '2023-04-24 16:41:55', 0),
        (18, 'test', 'Test', 'student2', 'Student2', 'Removed Booking by Test', 'Reservation has been removed by Test.', 0, '2023-04-24 16:43:10', 0),
        (19, 'test', 'Test', 'student2', 'Student2', 'Removed Booking by Test', 'Reservation has been removed by Test.', 0, '2023-04-24 16:43:46', 0),
        (20, 'test', 'Test', 'student2', 'Student2', 'Removed Booking by Test', 'Reservation has been removed by Test.', 0, '2023-04-24 16:45:44', 0),
        (21, 'test', 'Test', 'student2', 'Student2', 'Removed Booking by Test', 'Reservation has been removed by Test.', 0, '2023-04-24 16:53:02', 0),
        (22, 'test', 'Test', 'student2', 'Student2', 'Removed Booking by Test', 'Reservation has been removed by Test.', 0, '2023-04-24 16:55:12', 0),
        (23, 'student', 'Student', 'student4', 'Student4', 'Meeting', 'A reservation has been placed for the event.', 0, '2023-05-08 15:21:21', 0);";
        $stmt6 = $pdo->prepare($sql_insert_values_messages);
        $stmt6->execute();

        // creation of replies table
        $sql_replies = "CREATE TABLE `Replies` (
            `id` int(11) NOT NULL PRIMARY KEY,
            `message_id` int(11) NOT NULL,
            `sender` varchar(25) NOT NULL,
            `message` text NOT NULL,
            `sent_date` datetime NOT NULL DEFAULT current_timestamp()
          ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
        $stmt7 = $pdo->prepare($sql_replies);
        $stmt7->execute();

        // inserting values for replies table
        $sql_insert_values_replies = "INSERT INTO `Replies` (`id`, `message_id`, `sender`, `message`, `sent_date`) VALUES
        (1, 1, 'student', 'sjghjdsflsdjfskdfsdk', '2023-05-02 18:36:06'),
        (2, 1, 'student2', 'dkofjgsdkfjsdkj', '2023-05-02 18:36:06'),
        (3, 1, 'student', ' sdjgsdkjgdskjgdfksd;lkfsd\'', '2023-05-02 18:36:48');";
        $stmt8 = $pdo->prepare($sql_insert_values_replies);
        $stmt8->execute();
        $alter_table = "ALTER TABLE `Replies` ADD KEY `fk_1` (`message_id`);";
        $stmt9 = $pdo->prepare($alter_table);
        $stmt9->execute();
        // Foreign key constraints is created
        $alter_table_replies = "ALTER TABLE `Replies`
        ADD CONSTRAINT `fk_1` FOREIGN KEY (`message_id`) REFERENCES `Messages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;";
        $stmt10 = $pdo->prepare($alter_table_replies);
        $stmt10->execute();

        // modifies the table's primary key to auto increment with next value of the primary key
        $modify_events = "ALTER TABLE `Events` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;";
        $stmt10 = $pdo->prepare($modify_events);
        $stmt10->execute();
        $modify_login = "ALTER TABLE `Login` MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;";
        $stmt11 = $pdo->prepare($modify_login);
        $stmt11->execute();
        $modify_replies = "ALTER TABLE `Replies` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;";
        $stmt13 = $pdo->prepare($modify_replies);
        $stmt13->execute();
        echo "Database has been created.";
        exit();
    }

?>
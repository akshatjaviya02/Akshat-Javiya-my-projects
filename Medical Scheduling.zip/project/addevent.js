function verify_inputs() {
    // verify the inputs from add event html.
    let title = document.querySelectorAll(".title");
    let start_times = document.querySelectorAll(".start");
    let end_times = document.querySelectorAll(".end");
    let description = document.querySelectorAll(".description");
    let food = document.querySelectorAll(".food");
    let location = document.querySelectorAll(".location");
    let start_date = new Date(start_times.values);
    let end_date = new Date(end_times.values);
    let valid = true;
    if (title.length != 0 || start_times.length != 0 || end_times.length != 0 || description.length != 0 || food.length != 0 || location.length != 0 || start_date > end_date) {
        valid = false;
        error_check();
    }
    return valid;
}

function Private() {
    // to display designed username input for specific user
    let user = document.querySelector(".username");
    user.style.setProperty("--hidden", "visible");
    user.style.setProperty("--none", "block");
}
function error_check() {
    if (document.location.href.indexOf("?") != -1) {
        error.style.setProperty('--hidden', 'visible');
        error.style.setProperty('--none', 'block');
    } 
}
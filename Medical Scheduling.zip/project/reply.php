<?php
    session_start();
    include 'connection.php';
    // this will create an row cordinating with the message_id.
    $query = "INSERT INTO `Replies` (`message_id`, `sender`, `message`) VALUES (:id, :sender, :message);";
    $stmt = $pdo->prepare($query);
    $stmt->execute(["id" => $_POST['message_id'], "sender" => $_SESSION['username'], "message" => $_POST['message']]);
    if ($stmt) {
        header("Location: inbox.html");
    } else {
        header("Location: inbox.html");
    }
?>
<?php
    include 'connection.php';
    //This query will return distinct practice from login tables for users who are siging in to the system.
    $data2 = json_decode(file_get_contents("php://input"), true);
    $query = "SELECT DISTINCT(practice) FROM Login;";
    $stmt = $pdo->prepare($query);
    $stmt->execute();
    $result = $stmt->fetchAll();
    echo json_encode($result, JSON_PRETTY_PRINT);
    
?>
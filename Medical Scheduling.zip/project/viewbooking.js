const login_button = document.querySelector(".login");
const sign_up = document.querySelector(".logins");
const nav_links = document.querySelector(".nav_links");
const go_back_btn = document.querySelector(".go_back");
const directions = document.querySelector(".directions");
const bookings = document.querySelector(".bookings");
const booking = document.querySelector(".booking");
const confirm_div = document.querySelector(".confirm-div");
const confirm_div_booing = document.querySelector(".confirm-div-booking");
let all_bookings;
let all_events;
let new_id;
let event_id;
window.onload = function () {
    row();
    get_booking();
    get_events();
};

function get_booking() {
    // this function will get the bookings from the database.
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "view Booking.php", true);
    xhr.onload = function () {
        if (xhr.responseText == "Error: No Bookings found") {
            bookings.innerHTML = "No Bookings found";
            all_bookings = "No Bookings found";
        }
        else {
            let data = JSON.parse(xhr.responseText);
            all_bookings = data;
        }
    };
    xhr.send();
}
function get_events() {
    // this function will get the events from the database.
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "view events.php", true);
    xhr.onload = function () {
        if (xhr.responseText == "Error: No events found") {
            bookings.innerHTML = "No Events found";
            all_events = "No Events found";
        }
        else {
            let data = JSON.parse(xhr.responseText);
            all_events = data;
            view_booking();
        }
    };
    xhr.send();
}
function view_booking() {
    // this function will display the bookings on the screen.
    bookings.style.setProperty("--hidden", "visible");
    bookings.style.setProperty("--none", "block");
    booking.style.setProperty("--hidden", "invisible");
    booking.style.setProperty("--none", "none");
    go_back_btn.style.setProperty("--hidden", "invisible");
    go_back_btn.style.setProperty("--none", "none");

    let html = "";
    if(all_bookings == "No Bookings found") {
        bookings.innerHTML = "No Bookings found";
    } 
    else {
        for (let i = 0; i < all_bookings.length; i++) {
            html += `<div class="booking-row">
            <div class="items">
                        <a class="message" href="javascript:void(0);" onclick="display_booking(${all_bookings[i].id})">
                            <h5 class="name">${all_bookings[i].username}</h5>
                            <h5 class="subject">${all_bookings[i].title}</h5>
                            <h5 class="message">- ${all_bookings[i].description.slice(0, 20)}...</h5>
                            <h5 class="time">${all_bookings[i].start_time.slice(0, 10)}</h5>   
                        </a>
                    </div>
                </div>
                `;
        }
        bookings.innerHTML = html;
    }
}
function display_booking(id) {
    // this function will display specific booking.
    let html = "";
    event_id = id;
    const result = all_bookings.find(({ id }) => id === event_id);
    bookings.style.setProperty("--hidden", "invisible");
    bookings.style.setProperty("--none", "none");
    booking.style.setProperty("--hidden", "visible");
    booking.style.setProperty("--none", "block");
    go_back_btn.style.setProperty("--hidden", "visible");
    go_back_btn.style.setProperty("--none", "block");
    let description = result.description.replace(/\r\n/gi, "<br>");
    html += `
        <h3 class="sender">Event username: ${result.username}</h3>
        <h3 class="sender_name">Person's Name: ${result.name} </h3> 
        <h3 class="start_date">Start date: ${result.start_time.slice(0, 10)}</h3> 
        <h3 class="start_time">Start time: ${result.start_time.slice(10, result.start_time.length - 1)}</h3> 
        <h3 class="end_date">End date: ${result.end_time.slice(0, 10)}</h3> 
        <h3 class="end_time">End time: ${result.end_time.slice(10, result.end_time.length - 1)}</h3> 
        <h3 class="subjects">Title: ${result.title}</h3>
        <h3 class="messages">${description}</h3>
        <button class="book" type="submit" onclick="confirm_booking(${result.id});">Remove Booking</button>
        `;
        
    booking.innerHTML = html;
}

function back_page() {
    // this function is will hide thing and visible things according to view bookings or view events functions.
    go_back_btn.style.setProperty("--hidden", "invisible");
    go_back_btn.style.setProperty("--none", "none");
    bookings.style.setProperty("--hidden", "visible");
    bookings.style.setProperty("--none", "block");
    booking.style.setProperty("--hidden", "invisible");
    booking.style.setProperty("--none", "none");
    view_booking(all_bookings)
}

function view_events() {
    // this function is will display events on the screen. 
    bookings.style.setProperty("--hidden", "visible");
    bookings.style.setProperty("--none", "block");
    booking.style.setProperty("--hidden", "invisible");
    booking.style.setProperty("--none", "none");
    go_back_btn.style.setProperty("--hidden", "invisible");
    go_back_btn.style.setProperty("--none", "none");
    let html = "";
    if(all_events == "No Events found") {
        bookings.innerHTML = "No Events found";
        return ;
    } 
    else {
        for (let i = 0; i < all_events.length; i++) {
            html += `<div class="booking-row">
            <div class="items">
                        <a class="message" href="javascript:void(0);" onclick="display_events(${all_events[i].id})">
                            <h5 class="name">${all_events[i].username}</h5>
                            <h5 class="subject">${all_events[i].title}</h5>
                            <h5 class="message">- ${all_events[i].description.slice(0, 20)}...</h5>
                            <h5 class="time">${all_events[i].start_time.slice(0, 10)}</h5>   
                        </a>
                    </div>
                </div>
                `;
        }
        bookings.innerHTML = html;
    }
}
function confirm_booking(id) {
    // this function will unhide confirm booking div.
    new_id = id;
    confirm_div_booing.style.setProperty('--hidden', 'visibile');
    confirm_div_booing.style.setProperty('--none','block');
}
function cancel_booking() {
    // this function will hides confirm booking div.
    confirm_div_booing.style.setProperty('--none','none');
    confirm_div_booing.style.setProperty('--hidden', 'invisibile');
}
function confirm(id) {
    new_id = id;
    // this function will unhide confirm events div.
    confirm_div.style.setProperty('--hidden', 'visibile');
    confirm_div.style.setProperty('--none','block');
}
function cancel_book() {
    // this function will hide confirm events div.
    confirm_div.style.setProperty('--none','none');
    confirm_div.style.setProperty('--hidden', 'invisibile');
}
function remove_event() {
    // this function will remove the event from database and redirects to view events function.
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "remove_events.php", true);
    xhr.onload = function() {
        if(xhr.responseText == "Success") {
            cancel_book();
            all_events.pop(new_id);
            if(all_events.length == 0) {
                all_events = "No Bookings found"
            }
            view_events();
        }
    }
    xhr.send(JSON.stringify({"id" : new_id}));
}
function display_events(id) {
    // this function will display specific event.
    let html = "";
    event_id = id;
    const result = all_events.find(({ id }) => id === event_id);
    bookings.style.setProperty("--hidden", "invisible");
    bookings.style.setProperty("--none", "none");
    booking.style.setProperty("--hidden", "visible");
    booking.style.setProperty("--none", "block");
    go_back_btn.style.setProperty("--hidden", "visible");
    go_back_btn.style.setProperty("--none", "block");
    let description = result.description.replace(/\r\n/gi, "<br>");

    if (result.Booked == 1) {
        html += `
            <h3 class="sender">Event username: ${result.username}</h3>
            <h3 class="sender_name">Person's Name: ${result.name} </h3> 
            <h3 class="start_date">Start date: ${result.start_time.slice(0, 10)}</h3> 
            <h3 class="start_time">Start time: ${result.start_time.slice(10, result.start_time.length - 1)}</h3> 
            <h3 class="end_date">End date: ${result.end_time.slice(0, 10)}</h3> 
            <h3 class="end_time">End time: ${result.end_time.slice(10, result.end_time.length - 1)}</h3> 
            <h3 class="booked_username">Booked Username: ${result.booked_username}</h3>
            <h3 class="booked_name">Booked Person's Name: ${result.booked_name}</h3>
            <h3 class="subjects">Title: ${result.title}</h3>
            <h3 class="messages">${description}</h3>
            <button class="book" type="submit" onclick="confirm(${result.id});">Remove Event</button>
        `;
    }
    else {

        html += `
            <h3 class="sender">Event username: ${result.username}</h3>
            <h3 class="sender_name">Person's Name: ${result.name} </h3> 
            <h3 class="start_date">Start date: ${result.start_time.slice(0, 10)}</h3> 
            <h3 class="start_time">Start time: ${result.start_time.slice(10, result.start_time.length - 1)}</h3> 
            <h3 class="end_date">End date: ${result.end_time.slice(0, 10)}</h3> 
            <h3 class="end_time">End time: ${result.end_time.slice(10, result.end_time.length - 1)}</h3> 
            <h3 class="subjects">Title: ${result.title}</h3>
            <h3 class="booked">Booked: ${result.Booked}</h3>
            <h3 class="messages">${description}</h3>
            <button class="book" type="submit" onclick="confirm(${result.id});">Remove Event</button>
        `;
    }
    booking.innerHTML = html;
}
function remove_booking() {
    // this function will remove the bookings and redirect to the view_booking function.
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "remove_booking.php", true);
    xhr.onload = function() {
        if(xhr.responseText == "success") {
            cancel_booking();
            all_bookings.pop(event_id);
            if(all_bookings.length == 0) {
                all_bookings = "No Bookings found";
            }
            view_booking();

        }
    }

    xhr.send(JSON.stringify({"id" : event_id}));
}
function row() {
    // this function is used to verify authentication of the user.
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "authenication.php", true);
    xhr.onload = function () {
        if(xhr.responseText == "sucess") {
            login_button.remove();
            sign_up.remove();

            const li4 = document.createElement("li");
            const href4 = document.createElement("a");
            href4.setAttribute("href", "view booking.html");
            let t4 = document.createTextNode("View Bookings");
            href4.appendChild(t4);
            li4.appendChild(href4);
            nav_links.insertBefore(li4, directions);

            const li5 = document.createElement("li");
            const href5 = document.createElement("a");
            href5.setAttribute("href", "provider.html");
            let t5 = document.createTextNode("Find Provider");
            href5.appendChild(t5);
            li5.appendChild(href5);
            nav_links.insertBefore(li5, directions);

            const li3 = document.createElement("li");
            const href3 = document.createElement("a");
            href3.setAttribute("href", "schedule.html");
            let t3 = document.createTextNode("Schedule Meeting");
            href3.appendChild(t3);
            li3.appendChild(href3);
            nav_links.insertBefore(li3, directions);

            const li = document.createElement("li");
            const href = document.createElement("a");
            href.setAttribute("href", "edit-profile.html");
            let t = document.createTextNode("Edit Profile");
            href.appendChild(t);
            li.appendChild(href);
            nav_links.appendChild(li);

            const li2 = document.createElement("li");
            const href2 = document.createElement("a");
            href2.setAttribute("href", "inbox.html");
            let t2 = document.createTextNode("Inbox");
            href2.appendChild(t2);
            li2.appendChild(href2);
            nav_links.appendChild(li2);
            
            const li1 = document.createElement("li");
            const href1 = document.createElement("a");
            href1.setAttribute("href", "logout.php");
            let t1 = document.createTextNode("Logout");
            href1.appendChild(t1);
            li1.appendChild(href1);
            nav_links.appendChild(li1);
        }
        else {
            window.location.href = "login.html";
        }
    };
    xhr.send();
}

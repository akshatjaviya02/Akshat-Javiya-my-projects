<?php
    session_start();
    include 'connection.php';
    // this query will return all the bookings where current user is assigned.
    $query = "SELECT * FROM Events WHERE booked_username = :username AND booked_name = :name";
    $stmt = $pdo->prepare($query);
    $stmt->execute(["username" => $_SESSION['username'], "name" => $_SESSION['name']]);
    $results = $stmt->fetchAll();
    $all_emails = array();
    $arrays = array();
    if (count($results) == 0) {
        echo "Error: No Bookings found";
        exit();
    }
    else {
        foreach($results as $row) {
            $arrays["id"] = $row->id;
            $arrays["username"] = $row->username;
            $arrays["name"] = $row->name;
            $arrays["title"] = $row->title;
            $arrays["start_time"] = $row->start_time;
            $arrays["end_time"] = $row->end_time;
            $arrays["description"] = $row->description;
            $arrays["food"] = $row->food;
            $arrays["location"] = $row->location;
            $arrays["Booked"] = $row->Booked;
            array_push($all_emails, $arrays);
        }
    }
    echo json_encode($all_emails, JSON_PRETTY_PRINT);    
?>
const login_button = document.querySelector(".login");
const sign_up = document.querySelector(".logins");
const nav_links = document.querySelector(".nav_links");
const directions = document.querySelector(".directions");
const body2 = document.querySelector(".body2");
const addevent = document.querySelector(".addevent_link");
const list_events_btn = document.querySelector(".list_events");
const preference = document.querySelector(".choosing_preference");
const calendar_events = document.querySelector('.calendar_events');
let preference_data;
let selected_preference;
let list_all_events;
let list_all_providers;
let all_events;
let new_id;
window.onload = function () {
    row();
    preferences()
};
function preferences_selected() {
    // this functon will get the value of the selected preference
    let values = new Array;
    const selected = document.getElementsByName("preference")
    for (let i = 0; i < selected.length; i++) {
        if(selected[i].checked) {
            values.push(selected[i].value);
        }
    }
    selected_preference = values;
    generate_events(values);
}
function list_events() {
    // This function will invisible most of calendar attributes for display purposes.
    // This function will display events which were got from sql query but in list form.
    preference.style.setProperty("--hidden", "invisible");
    preference.style.setProperty("--none", 'none');
    addevent.style.setProperty("--hidden", "visible");
    addevent.style.setProperty("--none", "block");
    calendar_events.style.setProperty("--hidden", "visible");
    calendar_events.style.setProperty("--none", 'block');
    list_events_btn.style.setProperty("--hidden", "invisible");
    list_events_btn.style.setProperty("--none", "none");
    body2.style.setProperty("--hidden", "visible");
    body2.style.setProperty("--none", "block");
    if (all_events == "No events found") {        
        body2.innerHTML = `<p class="description">No events found </p>`;
    }
    else {
        let html = "";
        for (let i = 0; i < all_events.length; i++) {
            let start_date = all_events[i].start.slice(0, 10);
            let start_time = all_events[i].start.slice(10, all_events[i].start.length - 1);
            let end_date = all_events[i].end.slice(0, 10);
            let end_time = all_events[i].end.slice(10, all_events[i].end.length - 1);
            let url = "description.html?event_id=" + encodeURIComponent(all_events[i].id);
            html += `<a class="description" href="${url}"><label>${all_events[i].title}</label><label>${start_date}</label><label>${start_time}</label><label>${end_date}</label><label>${end_time}</label></a><br>`;
    
        }
        html += `<button class="calendar_events" type="submit" onclick="calendar()">Events calendar view</button>`;
        body2.innerHTML = html;
    }
}

function generate_events(option) {
    // this function will get the events from the database and save them to the array for the calendar to have it.
    preference.style.setProperty("--hidden", "invisible");
    preference.style.setProperty("--none", 'none');
    addevent.style.setProperty("--hidden", "visible");
    addevent.style.setProperty("--none", "block"); 
    list_events_btn.style.setProperty("--hidden", "visible");
    list_events_btn.style.setProperty("--none", "block");
    body2.style.setProperty("--hidden", "visible");
    body2.style.setProperty("--none", "block");
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "events.php", true);
    xhr.onload = function () {
        if (xhr.responseText == "Error: No events found") {
            all_events = "No events found";
        }
        else {
            let data = JSON.parse(xhr.responseText);
            let events = new Array;
            for (let i = 0; i < data.length; i++) {
                    events.push({
                        id: data[i].id,
                        title: data[i].title,
                        start: data[i].start_time,
                        end: data[i].end_time,
                    });
                }
                all_events = events;
        }
        if (all_events == "No events found") {
            list_events()
        } else {
            calendar();   
        }
    }
    xhr.send(JSON.stringify({preferences: option}));
}
function calendar() {
    // this function will display the calendar on the screen.
    body2.innerHTML = `<button class="list_events" type="submit" onclick="list_events()">Events list view</button> `;
    calendar_events.style.setProperty("--hidden", "invisible");
    calendar_events.style.setProperty("--none", 'none');
    list_events_btn.style.setProperty("--hidden", "visible");
    list_events_btn.style.setProperty("--none", "block");
    let calendarEl = document.querySelector('.body2');
    let calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        editable: true,
        selectable: true,
        eventClick: function (event) {
            event.jsEvent.preventDefault();
            let url = "description.html?event_id=" + encodeURIComponent(event.event.id);
            document.location.href = url;
            
        },
        events: all_events,
    });
    calendar.render();
}
function preferences() {
    // this function will get the preferences from the database
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "preference.php", true);
    xhr.onload = function () {
        if (xhr.responseText == "Error: No preference chosen.") {
            console.log(xhr.responseText);
        }
        else {
            let data = JSON.parse(xhr.responseText);
            display_preference(data)
        }
        
    }
    xhr.send();
}
function display_preference(data) {
    // this function will display the preference
    let html = "";
    preference_data = data;
    preference.style.setProperty("--hidden", "visible");
    preference.style.setProperty("--none", "block");
    for (let i = 0; i < preference_data.length; i++) {
        html += `<input type="checkbox" name="preference" value="${preference_data[i]}"> <label>${preference_data[i]}<br></label>`;   
    }
    html += `<button type="submit" class="select" onclick="select_all()">Select All</button>
    <button type="submit" class="clear" onclick="clear_all()">Clear All</button>
    <button type="submit" class="submit" onclick="preferences_selected()">Next</button>`;
    preference.innerHTML = html;
}
function select_all() {
    // this function will select all preferences
    for (let i = 0; i < preference_data.length; i++) { 
        const to_select = document.getElementsByName("preference");
        if(to_select[i].type=='checkbox')  {
            to_select[i].checked=true;  
        }  
   }
}
function clear_all() {
    // this function will clear all selected preference
    for (let i = 0; i < preference_data.length; i++) { 
        const to_select = document.getElementsByName("preference");
        if(to_select[i].type=='checkbox')  {
            to_select[i].checked=false;  
        }  
   }
}
function row() {
    // authentication function
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "authenication.php", true);
    xhr.onload = function () {
        if(xhr.responseText == "sucess") {
            login_button.remove();
            sign_up.remove();

            const li4 = document.createElement("li");
            const href4 = document.createElement("a");
            href4.setAttribute("href", "view booking.html");
            let t4 = document.createTextNode("View Bookings");
            href4.appendChild(t4);
            li4.appendChild(href4);
            nav_links.insertBefore(li4, directions);

            const li5 = document.createElement("li");
            const href5 = document.createElement("a");
            href5.setAttribute("href", "provider.html");
            let t5 = document.createTextNode("Find Provider");
            href5.appendChild(t5);
            li5.appendChild(href5);
            nav_links.insertBefore(li5, directions);

            const li3 = document.createElement("li");
            const href3 = document.createElement("a");
            href3.setAttribute("href", "schedule.html");
            let t3 = document.createTextNode("Schedule Meeting");
            href3.appendChild(t3);
            li3.appendChild(href3);
            nav_links.insertBefore(li3, directions);

            const li = document.createElement("li");
            const href = document.createElement("a");
            href.setAttribute("href", "edit-profile.html");
            let t = document.createTextNode("Edit Profile");
            href.appendChild(t);
            li.appendChild(href);
            nav_links.appendChild(li);

            const li2 = document.createElement("li");
            const href2 = document.createElement("a");
            href2.setAttribute("href", "inbox.html");
            let t2 = document.createTextNode("Inbox");
            href2.appendChild(t2);
            li2.appendChild(href2);
            nav_links.appendChild(li2);
            
            const li1 = document.createElement("li");
            const href1 = document.createElement("a");
            href1.setAttribute("href", "logout.php");
            let t1 = document.createTextNode("Logout");
            href1.appendChild(t1);
            li1.appendChild(href1);
            nav_links.appendChild(li1);
        }
        else {
            window.location.href = "login.html";
        }
    };
    xhr.send();
}

<?php
    session_start();
    include 'connection.php';
    $data = json_decode(file_get_contents("php://input"), true);
    // this query will update the booking by removing the booked username and name from the table
    $query = "UPDATE Events SET Booked = :booked, booked_username = :booked_username, booked_name = :booked_name WHERE id = :id";
    $stmt = $pdo->prepare($query);
    $stmt->execute(["booked" => 0, "booked_username" => NULL, "booked_name" => NULL, "id" => $data['id']]);
    if($stmt) {
        // this query will get the owner of the event by its id.
        $query2 = "SELECT username, name FROM Events WHERE id = :id;";
        $stmt2 = $pdo->prepare($query2);
        $stmt2->execute(['id' => $data['id']]);
        $results = $stmt2->fetchAll();
        // this query will send a message about reservation has be removed by the current user.
        $query3 = "INSERT INTO `Messages` (sender, sender_name, receiver, receiver_name, subject, message, seen, Important) VALUES (:sender, :sender_name, :receiver, :receiver_name, :subject, :message, :seen, :important);";
        $message = "Reservation has been removed by " . $_SESSION['name'] . ".";
        $subject = "Removed Booking by " . $_SESSION['name'];
        $stmt3 = $pdo->prepare($query3);
        $stmt3->execute(['sender' => $_SESSION['username'], 'sender_name' => $_SESSION['name'], 'receiver' => $results[0]->username, 'receiver_name' => $results[0]->name, 'subject' => $subject, 'message' => $message, 'seen' => 0, 'important' => 0]);
        if ($stmt3) {
            echo "success";
            exit();
        }
        else {
            echo "error";
            exit();
        }
    }
    else {
        echo "error";
        exit();
    }
?>
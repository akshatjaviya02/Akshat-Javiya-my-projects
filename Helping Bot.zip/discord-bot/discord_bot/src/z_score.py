from math import *
from numpy import *
import scipy.stats
DECIMAL = 6
async def p_value_to_z_scor(args):
    num2 = float(args[0])
    num2 = scipy.stats.norm.ppf(num2)
    num2 = round(num2, DECIMAL)
    if args[1] == "<" and num2 > 0:
        num2 = "-" + f"{num2:4f}"
    else:
        num2 = f"{num2:4f}"
    return num2

async def p_value_to_z_score_betwee(args):
    num1 = float(args)
    num2 = 1 - num1
    num3 = num1 + (num2 / 2)
    num4 = num1 + (num2 / 2)
    num5 = scipy.stats.norm.ppf(num3)
    num6 = scipy.stats.norm.ppf(num4) 
    num1 = round(num5, DECIMAL)
    num2 = round(num6, DECIMAL)
    num1 = "Lower bound : " + f"{num1:4f}" + "  Upper bound : " + f"{num2:4f}"
    return num1


async def z_scor(args):
    equation = []
    for x in args:
        if x.isdigit():
            num0 = int(x)
            equation.append(num0)
        else:
            num = float(x)
            equation.append(num)
    x_value = equation[0]
    mean = equation[1]
    sd = equation[2]
    num1 =  (x_value - mean) / sd
    num1 = round(num1, DECIMAL)
    num1 = f"{num1:6f}"
    return num1
async def z_score_1(args):
    equation = []
    for x in args:
        if x.isdigit():
            num0 = int(x)
            equation.append(num0)
        else:
            num = float(x)
            equation.append(num)
    mean = equation[0]
    sd = equation[1]
    num1 =  mean - sd
    num2 = mean + sd
    num1 = round(num1, DECIMAL)
    num2 = round(num2, DECIMAL)
    num1 = "Lower bound : " + f"{num1:4f}" + "  Upper bound : " + f"{num2:4f}"
    return num1

async def z_score_2(args):
    equation = []
    for x in args:
        if x.isdigit():
            num0 = int(x)
            equation.append(num0)
        else:
            num = float(x)
            equation.append(num)
    mean = equation[0]
    sd = equation[1]
    num1 =  mean - (2* sd)
    num2 = mean + (2* sd)
    num1 = round(num1, DECIMAL)
    num2 = round(num2, DECIMAL)
    num1 = "Lower bound : " + f"{num1:4f}" + "  Upper bound : " + f"{num2:4f}"
    return num1

async def z_score_3(args):
    equation = []
    for x in args:
        if x.isdigit():
            num0 = int(x)
            equation.append(num0)
        else:
            num = float(x)
            equation.append(num)
    mean = equation[0]
    sd = equation[1]
    num1 =  mean - (3 * sd)
    num2 = mean + (3 * sd)
    num1 = round(num1, DECIMAL)
    num2 = round(num2, DECIMAL)
    num1 = "Lower bound : " + f"{num1:4f}" + "  Upper bound : " + f"{num2:4f}"
    return num1    
async def z_score_top_p_valu(args):
    num2 = float(args[0])
    num2 = scipy.stats.norm.cdf(num2)
    num2 = round(num2, DECIMAL)
    if args[1] == "<":
        num2 = 1 - num2
        if  num2 < 0:
            num2 = "-" + f"{num2:4f}"
        else:
            num2 = f"{num2:4f}"
    elif args[1] == "=":
        num2 = 1 - num2
        num2 = num2 * 2
        if  num2 < 0:
            num2 = "-" + f"{num2:4f}"
        else:
            num2 = f"{num2:4f}"
    else:
        if  num2 < 0:
            num2 = "-" + f"{num2:4f}"
        else:
            num2 = f"{num2:4f}"
    return num2
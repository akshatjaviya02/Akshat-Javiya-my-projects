from math import *
from numpy import *
import scipy.stats

DECIMAL = 6
async def normal_distribution_less_tha(args):
    total = 0.0
    equation = []
    for x in args:
        if x.isdigit():
            num0 = int(x)
            equation.append(num0)
        else:
            num = float(x)
            equation.append(num)

    x_value = equation[0] 
    mean = equation[1]
    sd = equation[2]
    num1 = (x_value - mean) / sd
    num1 = round(num1, 2)
    num1 = scipy.stats.norm.cdf(num1)
    num1 = round(num1, DECIMAL)
    num1 = f"{num1:4f}"
    return num1


async def normal_distribution_greater_tha(args):
    dec = await normal_distribution_less_tha(args)
    dec = 1 - float(dec)
    dec = round(dec, DECIMAL)
    dec = f"{dec:4f}"
    return dec

async def normal_distribution_rang(args):
    total = 0.0
    equation = []
    for x in args:
        if x.isdigit():
            num0 = int(x)
            equation.append(num0)
        else:
            num = float(x)
            equation.append(num)

    x_value_min = equation[0]
    x_value_max = equation[1] 
    mean = equation[2]
    sd = equation[3]
    num1 = (x_value_min - mean) / sd
    num1 = scipy.stats.norm.cdf(num1)
    num2 = (x_value_max - mean) / sd
    num2 = scipy.stats.norm.cdf(num2)
    total = num2 - num1
    total = round(total, DECIMAL)
    total = f"{total:4f}"
    return total


import sys
import mysql.connector
from math import *
from numpy import *
import scipy.stats
DECIMAL = 6
THREE_DEC = 3
async def sample_error(args):
    equation = []
    for x in args:
        if x.isdigit():
            num0 = int(x)
            equation.append(num0)
        else:
            num = float(x)
            equation.append(num)
    p_value = equation[0]
    n_value = equation[1]
    num1 = p_value * (1 - p_value)
    num2 = num1 / n_value
    num2 = sqrt(num2)
    num2 = round(num2, DECIMAL)
    num2 = f"{num2:4f}"
    return num2

async def margin_erro(args):
    dec = await sample_error(args)
    dec = float(dec)
    dec = round(dec, DECIMAL)
    equation = []
    for x in args:
        if x.isdigit():
            num0 = int(x)
            equation.append(num0)
        else:
            num = float(x)
            equation.append(num)
    per = equation[2]
    if isinstance(per, int):
        per = ((100 - per)/100) / 2
    else:
        per = (1 - per) / 2
    t_value = scipy.stats.norm.ppf(per)
    t_value = abs(t_value)
    t_value = round(t_value, THREE_DEC)
    num1 = t_value * dec
    num1 = round(num1, DECIMAL)
    num1 = f"{num1:3f}" 
    return num1


async def point_estimat(args):
    p_value = float(args[0])
    margin_error = await margin_erro(args)
    margin_error = float(margin_error)
    margin_error = round(margin_error, DECIMAL)
    num1 = p_value - margin_error
    num2 = p_value + margin_error 
    num1 = round(num1, DECIMAL)
    num2 = round(num2, DECIMAL)
    num1 = "Lower bound : " + f"{num1:4f}" + "  Upper bound : " + f"{num2:4f}"
    return num1


async def t_distribution(args):
    equation = []
    for x in args:
        if x.isdigit():
            num0 = int(x)
            equation.append(num0)
        else:
            num = float(x)
            equation.append(num)
    sd_value =  equation[0]
    n_value = equation[1]
    num1 = sd_value / (sqrt(n_value))
    num1 = round(num1, DECIMAL)
    num1 = f"{num1:4f}"
    return num1


async def t_distribution_one(args):
    sd = await t_distribution(args)
    sd = float(sd)
    equation = []
    for x in args:
        if x.isdigit():
            num0 = int(x)
            equation.append(num0)
        else:
            num = float(x)
            equation.append(num)
    n_value = equation[1]
    x_value = equation[2]
    n_value = n_value - 1
    p_value = equation[3]
    if isinstance(p_value, int):
        p_value = ((100 - p_value)/100) / 2
    else:
        p_value = (1 - p_value) / 2
    
    t_value = scipy.stats.t.ppf(q=p_value, df=n_value)
    num1 = x_value - (t_value * sd)
    num2 = x_value + (t_value * sd)
    num1 = round(num1, DECIMAL)
    num2 = round(num2, DECIMAL)
    num1 = "Lower bound : " + f"{num1:4f}" + "  Upper bound : " + f"{num2:4f}"
    return num1

async def t_distribution_two(args):
    sd = await t_distribution(args)
    sd = float(sd)
    equation = []
    for x in args:
        if x.isdigit():
            num0 = int(x)
            equation.append(num0)
        else:
            num = float(x)
            equation.append(num)
    n_value = equation[1]
    x_value = equation[2]
    n_value = n_value - 1
    p_value = equation[3]
    if isinstance(p_value, int):
        p_value = ((100 - p_value)/100)
    else:
        p_value = (1 - p_value) 
    t_value = scipy.stats.t.ppf(q=p_value, df=n_value)
    num1 = x_value - (t_value * sd)
    num2 = x_value + (t_value * sd)
    num1 = round(num1, DECIMAL)
    num2 = round(num2, DECIMAL)
    num1 = "Lower bound : " + f"{num1:4f}" + "  Upper bound : " + f"{num2:4f}"
    return num1    
async def point_estimate_without_p_value(args):
    num1 = int(args[0])
    num2 = int(args[1])
    num1 = num1 / num2
    num1 = round(num1, 5)
    num1 = f"{num1:4f}"
    equation = list(args)
    equation[0] = num1
    args = tuple(equation)
    num1 = await point_estimat(args)
    return num1
    
import sys
import mysql.connector
from math import *
from numpy import *
import scipy.stats
DECIMAL = 6
sys.path.insert(0, '/home/student/secret')
from secret import Token, mydb

async def Ib():
    option = "$C (normal, bionomial, geometric, p_value, z-score, point_estimate, standard_error, t-distribution) to categorize formula's name.\n$all_formulas to see all the names of formulas.\n$F and formula name to see the description of it."
    option = option + "\n$FC category name will give the formula name."
    return option
async def combinatio(args):
    
    num = int(args[0])
    num1 = int(args[1])
    num2 = factorial(num)
    num3 = num - num1
    num4 = factorial(num3)
    num4 = num2 / ((factorial(num1)) * num4)
    num4 = round(num4, DECIMAL)
    return num4

async def Fb(arg):
    c = mydb.cursor()
    stored = "SELECT formula FROM formulas WHERE idname = %s"
    paramerter = arg
    c.execute(stored, paramerter)
    formula = c.fetchall()
    if len(formula) != 0:
        f = formula[0][0]
        return f
    else:
        return "No formula found."
async def Ff(arg):
    Formulas = ""
    c = mydb.cursor()
    stored = "SELECT idname FROM formulas WHERE chatper_number = %s"
    paramerter = arg
    c.execute(stored, paramerter)
    formula = c.fetchall()
    if len(formula) == 0:
        return "No formula found."
    for lis in formula:
        for l in lis:
            Formulas =  Formulas + "$" + l + "\n"
    return Formulas
async def Sf(arg):
    Formulas = ""
    c = mydb.cursor()
    stored = "SELECT idname FROM formulas WHERE section_number = %s"
    paramerter = arg
    c.execute(stored, paramerter)
    formula = c.fetchall()
    if len(formula) == 0:
        return "No formula found."
    for lis in formula:
        for l in lis:
            Formulas =  Formulas + "$" + l + "\n"
    return Formulas    

async def all():
    #formula = "$F geometric_mean, $F geometric_sd, $F geometric_equal, $F geometric_less_than, $F geometric_less_than_or_equal, $F geometric_greater_than, $F geometric_greater_than_or_equal, $F geometric_range_less, $F geometric_range_equal, $F bionomial_equal,"
    #formula = formula + " $F bionomial_less_than, $F bionomial_less_than_or_equal, $F bionomial_greater_than, $F bionomial_greater_than_or_equal, $F bionomial_mean, $F bionomial_sd, $F bionomial_range_equal, $F bionomial_range_greater_than_and_equal"
    #formula = formula + "$F bionomial_range_equal_less_than, $F bionomial_range_greater_than_and_less_than"
    Formulas = ""
    c = mydb.cursor()
    c.execute("SELECT idname FROM formulas")
    formula = c.fetchall()
    if len(formula) == 0:
        return "No formulas found. Please try again later."
    for lis in formula:
        for l in lis:
            Formulas =  Formulas + "$F " + l + ", "
    return Formulas
            
async def Cb(args):
    Formulas = ""
    c = mydb.cursor()
    stored = "SELECT idname FROM formulas WHERE category = %s"
    paramerter = args
    c.execute(stored, paramerter)
    formula = c.fetchall()
    if len(formula) != 0:
        for lis in formula:
            for l in lis:
                Formulas =  Formulas + "$F " + l + ", "
        return Formulas
    else:
        return "No formula found."
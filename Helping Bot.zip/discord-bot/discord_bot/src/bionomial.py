from math import *
DECIMAL = 6

#----------------------------------------START: RANGE FORMULAS FOR BIONOMIAL -------------------------------------------------

async def bionomial_range_greater_than_and_less_tha(args):
    total = 0.0
    equation = []
    for x in args:
        if x.isdigit():
            num0 = int(x)
            equation.append(num0)
        else:
            num = float(x)
            equation.append(num)
    n_value_max = equation[1]
    x_value_min = equation[2] + 1
    x_value_last = equation[3]

    for x in range(x_value_min, x_value_last): 
        num2 = factorial(n_value_max)
        num3 = n_value_max - x
        num4 = factorial(num3)
        c_value = num2 / ((factorial(x)) * num4)
        p_value = equation[0]
        q_value = 1 - p_value
        num5 = n_value_max - x
        num6 = q_value ** num5
        num7 = p_value ** x
        total = c_value * num6 * num7 + total
    total = round(total, DECIMAL)
    dec = f"{total:4f}"
    return dec

async def bionomial_range_equal_less_tha(args):
    total = 0.0
    equation = []
    for x in args:
        if x.isdigit():
            num0 = int(x)
            equation.append(num0)
        else:
            num = float(x)
            equation.append(num)
    n_value_max = equation[1]
    x_value_min = equation[2]
    x_value_last = equation[3]

    for x in range(x_value_min, x_value_last): 
        num2 = factorial(n_value_max)
        num3 = n_value_max - x
        num4 = factorial(num3)
        c_value = num2 / ((factorial(x)) * num4)
        p_value = equation[0]
        q_value = 1 - p_value
        num5 = n_value_max - x
        num6 = q_value ** num5
        num7 = p_value ** x
        total = c_value * num6 * num7 + total
    total = round(total, DECIMAL)
    dec = f"{total:4f}"
    return dec

async def bionomial_range_greater_than_and_equa(args):
    total = 0.0
    equation = []
    for x in args:
        if x.isdigit():
            num0 = int(x)
            equation.append(num0)
        else:
            num = float(x)
            equation.append(num)
    n_value_max = equation[1]
    x_value_min = equation[2] + 1
    x_value_last = equation[3] + 1

    for x in range(x_value_min, x_value_last): 
        num2 = factorial(n_value_max)
        num3 = n_value_max - x
        num4 = factorial(num3)
        c_value = num2 / ((factorial(x)) * num4)
        p_value = equation[0]
        q_value = 1 - p_value
        num5 = n_value_max - x
        num6 = q_value ** num5
        num7 = p_value ** x
        total = c_value * num6 * num7 + total
    total = round(total, DECIMAL)
    dec = f"{total:4f}"
    return dec

async def bionomial_range_equa(args):
    total = 0.0
    equation = []
    for x in args:
        if x.isdigit():
            num0 = int(x)
            equation.append(num0)
        else:
            num = float(x)
            equation.append(num)
    n_value_max = equation[1]
    x_value_min = equation[2]
    x_value_last = equation[3] + 1

    for x in range(x_value_min, x_value_last): 
        num2 = factorial(n_value_max)
        num3 = n_value_max - x
        num4 = factorial(num3)
        c_value = num2 / ((factorial(x)) * num4)
        p_value = equation[0]
        q_value = 1 - p_value
        num5 = n_value_max - x
        num6 = q_value ** num5
        num7 = p_value ** x
        total = c_value * num6 * num7 + total
    total = round(total, DECIMAL)
    dec = f"{total:4f}"
    return dec

#----------------------------------------END: RANGE FORMULAS FOR BIONOMIAL -------------------------------------------------

#--------------------------------- START: MEAN AND STANDARD DEVIATION FOR BIONOMIAL -------------------------------

async def bionomial_s(args):
    num1 = float(args[0])
    num2 = int(args[1])
    num2 = num1 * num2
    num2 = num2 * (1 - num1)
    num2 = sqrt(num2)
    num2 = round(num2, DECIMAL)
    return num2

async def bionomial_mea(args):
    num1 = float(args[0])
    num2 = int(args[1])
    num2 = num1 * num2
    num2 = round(num2, DECIMAL)
    return num2

#--------------------------------- END: MEAN AND STANDARD DEVIATION FOR BIONOMIAL -------------------------------


#--------------------------------- START: EQUAL, GREATER THAN OR EQUAL, LESS THAN OR EQUAL FORMULAS FOR BIONOMIAL -------------------------------

async def bionomial_greater_than_or_equa(args):
    total = 0.0
    n_value = int(args[1])
    x_value = int(args[2])
    for x in range(x_value, n_value): 
        num2 = factorial(n_value)
        num3 = n_value - x
        num4 = factorial(num3)
        c_value = num2 / ((factorial(x)) * num4)
        p_value = float(args[0])
        q_value = 1 - p_value
        num5 = n_value - x
        num6 = q_value ** num5
        num7 = p_value ** x
        total = c_value * num6 * num7 + total
    total = round(total, DECIMAL)
    dec = f"{total:4f}"
    return dec

async def bionomial_greater_tha(args):
    total = 0.0
    num = float(args[0])
    n_value = int(args[1])
    x_value = int(args[2]) + 1
    for x in range(x_value, n_value): 
        num2 = factorial(n_value)
        num3 = n_value - x
        num4 = factorial(num3)
        c_value = num2 / ((factorial(x)) * num4)
        p_value = float(args[0])
        q_value = 1 - p_value
        num5 = n_value - x
        num6 = q_value ** num5
        num7 = p_value ** x
        total = c_value * num6 * num7 + total
    total = round(total, DECIMAL)
    dec = f"{total:4f}"
    return dec

async def bionomial_less_than_or_equa(args):
    total = 0.0
    n_value = int(args[1])
    x_value = int(args[2]) + 1
    for x in range(1, x_value): 
        num2 = factorial(n_value)
        num3 = n_value - x
        num4 = factorial(num3)
        c_value = num2 / ((factorial(x)) * num4)
        p_value = float(args[0])
        q_value = 1 - p_value
        num5 = n_value - x
        num6 = q_value ** num5
        num7 = p_value ** x
        total = c_value * num6 * num7 + total
    total = round(total, DECIMAL)
    dec = f"{total:4f}"
    return dec

async def bionomial_less_tha(args):
    total = 0.0
    n_value = int(args[1])
    x_value = int(args[2])
    for x in range(1, x_value): 
        num2 = factorial(n_value)
        num3 = n_value - x
        num4 = factorial(num3)
        c_value = num2 / ((factorial(x)) * num4)
        p_value = float(args[0])
        q_value = 1 - p_value
        num5 = n_value - x
        num6 = q_value ** num5
        num7 = p_value ** x
        total = c_value * num6 * num7 + total
    total = round(total, DECIMAL)
    dec = f"{total:4f}"
    return dec

async def bionomial_equa(args):
    total = 0.0
    n_value = int(args[1])
    x_value = int(args[2])
    num2 = factorial(n_value)
    num3 = n_value - x_value
    num4 = factorial(num3)
    c_value = num2 / ((factorial(x_value)) * num4)
    p_value = float(args[0])
    q_value = 1 - p_value
    num5 = n_value - x_value
    num6 = q_value ** num5
    num7 = p_value ** x_value
    total = c_value * num6 * num7
    total = round(total, DECIMAL)
    dec = f"{total:8f}"
    return dec

#--------------------------------- END: EQUAL, GREATER THAN OR EQUAL, LESS THAN OR EQUAL FORMULAS FOR BIONOMIAL -------------------------------
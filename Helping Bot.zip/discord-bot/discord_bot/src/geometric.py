from math import *
DECIMAL = 6
#-------------------------------------- MEAN AND STANDARD DEVIATION FOR GEOMETRIC -----------------------------------------

async def geometric_mea(arg):
    num = float(arg)
    num = 1 / num
    num = round(num, DECIMAL)
    return num



async def geometric_s(arg):
    num1 = float(arg)
    num2 = 1 - num1
    num3 = num1 *num1
    num4 = num2 / num3
    num4 = sqrt(num4)
    num4 = round(num4, DECIMAL)
    return num4


#--------------------------------- EQUAL, GREATER THAN OR EQUAL, LESS THAN OR EQUAL FORMULAS-------------------------------
 
async def geometric_equa(args):
    total = 0.0
    equation = []
    for x in args:
        if x.isdigit():
            num0 = int(x)
            equation.append(num0)
        else:
            num = float(x)
            equation.append(num)
    percentage = equation[0]
    min = equation[1]
    num1 = min - 1
    num2 = 1 - percentage
    num2 = num2 ** num1
    total = (num2 * percentage) + total
    total = round(total, DECIMAL)
    return total
   


async def geometric_less_than_or_equa(args):  
    total = 0.0
    mum0 = 0
    num = 0.0
    for x in args:
        if x.isdigit():
            num0 = int(x)
        else:
            num = float(x)        
    num2 = 1 - num
    num2 = num2 ** num0 
    total = 1 - num2
    total = round(total, DECIMAL)
    return total


async def geometric_less_tha(args):  
    total = 0.0
    mum0 = 0
    num = 0.0
    for x in args:
        if x.isdigit():
            num0 = int(x)
        else:
            num = float(x)        
    num2 = 1 - num
    num2 = num2 ** (num0 - 1) 
    total = 1 - num2
    total = round(total, DECIMAL)
    return total


async def geometric_greater_tha(args):
    total = 0.0
    mum0 = 0
    num = 0.0
    for x in args:
        if x.isdigit():
            num0 = int(x)
        else:
            num = float(x)        
    total = (1 - num) ** num0
    total = round(total, DECIMAL)
    return total


async def geometric_greater_than_or_equa(args):
    total = 0.0
    mum0 = 0
    num = 0.0
    for x in args:
        if x.isdigit():
            num0 = int(x)
        else:
            num = float(x)        
    total = (1 - num) ** (num0 - 1)
    total = round(total, DECIMAL)
    return total

#----------------------------------------RANGE GEOMETRIC FORMULAS -------------------------------------------------
async def geometric_range_equa(args):
    total = 0.0
    equation = []
    for x in args:
        if x.isdigit():
            num0 = int(x)
            equation.append(num0)
        else:
            num = float(x)
            equation.append(num)
    percentage = equation[0]
    min = equation[1]
    max = equation[2] + 1
    for i in range(min, max):
        num1 = i - 1
        num2 = 1 - percentage
        num2 = num2 ** num1
        total = (num2 * percentage) +total    
    total = round(total, DECIMAL)
    return total

async def geometric_range_greater_than_and_less_tha(args):  
    total = 0.0
    equation = []
    for x in args:
        if x.isdigit():
            num0 = int(x)
            equation.append(num0)
        else:
            num = float(x)
            equation.append(num)
    percentage = equation[0]
    min = equation[1] + 1
    max = equation[2]
    for i in range(min, max):
        num1 = i - 1
        num2 = 1 - percentage
        num2 = num2 ** num1
        total = (num2 * percentage) +total    
    total = round(total, DECIMAL)
    return total

async def geometric_range_equal_and_less_tha(args):  
    total = 0.0
    equation = []
    for x in args:
        if x.isdigit():
            num0 = int(x)
            equation.append(num0)
        else:
            num = float(x)
            equation.append(num)
    percentage = equation[0]
    min = equation[1]
    max = equation[2]
    for i in range(min, max):
        num1 = i - 1
        num2 = 1 - percentage
        num2 = num2 ** num1
        total = (num2 * percentage) +total    
    total = round(total, DECIMAL)
    return total

async def geometric_range_greater_than_and_equa(args):  
    total = 0.0
    equation = []
    for x in args:
        if x.isdigit():
            num0 = int(x)
            equation.append(num0)
        else:
            num = float(x)
            equation.append(num)
    percentage = equation[0]
    min = equation[1] + 1
    max = equation[2] + 1
    for i in range(min, max):
        num1 = i - 1
        num2 = 1 - percentage
        num2 = num2 ** num1
        total = (num2 * percentage) +total    
    total = round(total, DECIMAL)
    return total
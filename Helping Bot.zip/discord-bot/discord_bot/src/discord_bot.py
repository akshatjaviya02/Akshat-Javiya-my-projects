import asyncio
from time import sleep
import discord
import os
import sys
from discord.ext import commands
from alive_bot import keep_alive
import mysql.connector
from bionomial import *
from geometric import *
from side_formulas import *
from z_score import *
from normal import *
from user_interface import *

sys.path.insert(0, '/home/student/secret')
from secret import Token, mydb
bot = commands.Bot("$", intents=discord.Intents.all())

#---------------------------- ALL FORMULAS' DESCRIPTION AND LIST OF FORMULAS ---------------------------------------------
@bot.command()
async def I(ctx):
    formula = await Ib()
    await ctx.send(formula)
@bot.command()
async def CN(ctx, *arg):
    formula = await Ff(arg)
    await ctx.send(formula)
@bot.command()
async def SN(ctx, *arg):
    formula = await Sf(arg)
    await ctx.send(formula)    
@bot.command()
async def C(ctx, *args):
    formula = await Cb(args)
    await ctx.send(formula)

@bot.command()
async def all_formulas(ctx):
    formula = await all()
    await ctx.send(formula)
    
@bot.command()
async def F(ctx, *arg):
    formula = await Fb(arg)
    await ctx.send(formula)
#-------------------------------------- START: MEAN AND STANDARD DEVIATION FOR GEOMETRIC -----------------------------------------

@bot.command()
async def geometric_mean(ctx, arg):
    num = await geometric_mea(arg)
    await ctx.send(num)



@bot.command()
async def geometric_sd(ctx, arg):
    num4 = await geometric_s(arg)
    await ctx.send(num4)

#-------------------------------------- END: MEAN AND STANDARD DEVIATION FOR GEOMETRIC -----------------------------------------

#----------------------------------------START: RANGE GEOMETRIC FORMULAS -------------------------------------------------

@bot.command()
async def geometric_range_equal(ctx, *args):
    total = await geometric_range_equa(args)
    await ctx.send(total)

@bot.command()
async def geometric_range_greater_than_and_less_than(ctx, *args):
    total = await geometric_range_greater_than_and_less_tha(args)
    await ctx.send(total)
    
@bot.command()
async def geometric_range_equal_and_less_than(ctx, *args):
    total = await geometric_range_less_tha(args)
    await ctx.send(total)

@bot.command()
async def geometric_range_greater_than_and_equal(ctx, *args):
    total = await geometric_range_greater_than_and_equa(args)
    await ctx.send(total)

#----------------------------------------END: RANGE GEOMETRIC FORMULAS -------------------------------------------------

#--------------------------------- START: EQUAL, GREATER THAN OR EQUAL, LESS THAN OR EQUAL FORMULAS FOR GEOMETRIC -------------------------------

@bot.command()
async def geometric_equal(ctx, *args):
    total = await geometric_equa(args)
    await ctx.send(total)
   

@bot.command()
async def geometric_less_than_or_equal(ctx, *args):  
    total = await geometric_less_than_or_equa(args)
    await ctx.send(total)

@bot.command()
async def geometric_less_than(ctx, *args):  
    total = await geometric_less_tha(args)
    await ctx.send(total)

@bot.command()
async def geometric_greater_than(ctx, *args):
    total = await geometric_greater_tha(args)
    await ctx.send(total)

@bot.command()
async def geometric_greater_than_or_equal(ctx, *args):
    total = await geometric_greater_than_or_equa(args)
    await ctx.send(total)

#--------------------------------- END: EQUAL, GREATER THAN OR EQUAL, LESS THAN OR EQUAL FORMULAS FOR GEOMETRIC-------------------------------


#--------------------------------- START: OTHER FORMULAS -----------------------------------------------------------------------

@bot.command()
async def combination(ctx, *args):
    total = await combinatio(args)
    await ctx.send(total)    

#--------------------------------- END: OTHER FORMULAS -----------------------------------------------------------------------

#--------------------------------- START: EQUAL, GREATER THAN OR EQUAL, LESS THAN OR EQUAL FORMULAS FOR BIONOMIAL -------------------------------

@bot.command() 
async def bionomial_equal(ctx, *args):
    dec = await bionomial_equa(args)
    await ctx.send(dec)

@bot.command()
async def bionomial_less_than(ctx, *args):
    dec = await bionomial_less_tha(args)
    await ctx.send(dec)

@bot.command()
async def bionomial_less_than_or_equal(ctx, *args):
    dec = await bionomial_less_than_or_equa(args)
    await ctx.send(dec)

@bot.command()
async def bionomial_greater_than(ctx, *args):
    dec = await bionomial_greater_tha(args)
    await ctx.send(dec)

@bot.command()
async def bionomial_greater_than_or_equal(ctx, *args):
    dec = await bionomial_greater_than_or_equa(args)
    await ctx.send(dec)

#--------------------------------- END: EQUAL, GREATER THAN OR EQUAL, LESS THAN OR EQUAL FORMULAS FOR BIONOMIAL -------------------------------

#--------------------------------- START: MEAN AND STANDARD DEVIATION FOR BIONOMIAL -------------------------------

@bot.command()
async def bionomial_mean(ctx, *args):
    dec = await bionomial_mea(args)
    await ctx.send(dec)
   

@bot.command()
async def bionomial_sd(ctx, *args):
    dec = await bionomial_sd(args)
    await ctx.send(dec)

#--------------------------------- END: MEAN AND STANDARD DEVIATION FOR BIONOMIAL -------------------------------

#----------------------------------------START: RANGE FORMULAS FOR BIONOMIAL -------------------------------------------------

@bot.command()
async def bionomial_range_equal(ctx, *args):
    dec = await bionomial_range_equa(args)
    await ctx.send(dec)

@bot.command()
async def bionomial_range_greater_than_and_equal(ctx, *args):
    dec = await bionomial_range_greater_than_and_equa(args)
    await ctx.send(dec)

@bot.command()
async def bionomial_range_equal_less_than(ctx, *args):
    dec = await bionomial_range_equal_less_tha(args)
    await ctx.send(dec)


@bot.command()
async def bionomial_range_greater_than_and_less_than(ctx, *args):
    dec = await bionomial_range_greater_than_and_less_tha(args)
    await ctx.send(dec)

#----------------------------------------END: RANGE FORMULAS FOR BIONOMIAL -------------------------------------------------

#----------------------------------------START: FORMULAS FOR NORMAL  -------------------------------------------------
@bot.command()
async def normal_distribution_less_than(ctx, *args):
    dec = await normal_distribution_less_tha(args)
    await ctx.send(dec)

@bot.command()
async def normal_distribution_greater_than(ctx, *args):
    dec = await normal_distribution_greater_tha(args)
    await ctx.send(dec)
@bot.command()
async def normal_distribution_between(ctx, *args):
    dec = await normal_distribution_rang(args)
    await ctx.send(dec)
#----------------------------------------END: FORMULAS FOR NORMAL  -------------------------------------------------

#----------------------------------------START: FORMULAS FOR Z-score -----------------------------------------------
@bot.command()
async def z_score(ctx, *args):
    dec = await z_scor(args)
    await ctx.send(dec)

@bot.command()
async def z_score_1_sd(ctx, *args):
    dec = await z_score_1(args)
    await ctx.send(dec)

@bot.command()
async def z_score_2_sd(ctx, *args):
    dec = await z_score_2(args)
    await ctx.send(dec)
@bot.command()
async def z_score_3_sd(ctx, *args):
    dec = await z_score_3(args)
    await ctx.send(dec)

@bot.command()
async def p_value_to_z_score(ctx, *args):
    dec = await p_value_to_z_scor(args)
    await ctx.send(dec)
        
@bot.command()
async def p_value_to_z_score_between(ctx, args):
    dec = await p_value_to_z_score_betwee(args)
    await ctx.send(dec)       
@bot.command()
async def z_score_to_p_value(ctx, *args):   
    dec = await z_score_top_p_valu(args)
    await ctx.send(dec)         
#----------------------------------------END: FORMULAS FOR Z-score -----------------------------------------------


#----------------------------------------START: FORMULAS FOR sampling error --------------------------------------
@bot.command()
async def standard_error(ctx, *args):
    dec = await sample_error(args)
    await ctx.send(dec)

@bot.command()
async def point_estimate_p_hat(ctx, *args):
    dec = await point_estimat(args)
    await ctx.send(dec)
@bot.command()
async def point_estimate(ctx, *args):
    dec = await point_estimate_without_p_value(args)
    await ctx.send(dec)
@bot.command()
async def margin_error(ctx, *args):
    dec = await margin_erro(args)
    await ctx.send(dec)

@bot.command()
async def t_distribution_sd(ctx, *args):
    dec = await t_distribution(args)
    await ctx.send(dec)
@bot.command()
async def t_distribution_one_pair(ctx, *args):
    dec = await t_distribution_one(args)
    await ctx.send(dec)

@bot.command()
async def t_distribution_two_pair(ctx, *args):
    dec = await t_distribution_two(args)
    await ctx.send(dec)
#----------------------------------------END: FORMULAS FOR sampling error --------------------------------------

def restart_program(args):
    python = sys.executable
    os.execl(python, python, * sys.argv)
@commands.is_owner()
@bot.command()
async def restart(ctx):
    sleep(60)
    restart_program("discord_bot.py user_interface.py side_formulas.py z_score.py geometric.py bionomial.py geometric.py")
bot.run(Token)


# Milestone 2

## Description
Describe what you did for this milestone in your own words.
We input pointers to the project and track the score.

## Challenges encountered
Describe the challenges you encountered while working on this milestone of the project.
Most difficult thing was implementing the pointers.

## Things I've learned
What is the most important thing you've learned from this milestone in the project?
Learned how to use pointer especially dramatic pointer.
